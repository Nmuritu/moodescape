# MoodScape Flutter - API Documentation

## Overview
This document describes the API services and data models used in the MoodScape Flutter application.

## Services

### AIService
Handles AI-powered mood analysis and recommendations.

#### Methods

##### `predictMoodFromText(String text)`
Analyzes text input to predict mood and provide insights.

**Parameters:**
- `text` (String): User's text input to analyze

**Returns:** `Future<MoodPrediction>`

**Example:**
```dart
final prediction = await AIService.predictMoodFromText("I had a great day today!");
print('Predicted mood: ${prediction.predictedMood}/10');
print('Confidence: ${prediction.confidence}');
```

##### `generateInsights(List<MoodEntry> entries)`
Generates AI-powered insights from mood entries.

**Parameters:**
- `entries` (List<MoodEntry>): List of mood entries to analyze

**Returns:** `Future<List<MoodInsight>>`

**Example:**
```dart
final insights = await AIService.generateInsights(moodEntries);
for (final insight in insights) {
  print('${insight.title}: ${insight.description}');
}
```

##### `getMoodRecommendations(double moodScore)`
Gets personalized recommendations based on mood score.

**Parameters:**
- `moodScore` (double): Current mood score (1-10)

**Returns:** `List<String>`

**Example:**
```dart
final recommendations = AIService.getMoodRecommendations(7.5);
for (final rec in recommendations) {
  print('- $rec');
}
```

### RecommendationsService
Provides personalized content recommendations.

#### Methods

##### `getMusicRecommendations(double moodScore)`
Gets music recommendations based on mood.

**Parameters:**
- `moodScore` (double): Current mood score (1-10)

**Returns:** `Future<List<Recommendation>>`

##### `getQuoteRecommendations(double moodScore)`
Gets inspirational quotes based on mood.

**Parameters:**
- `moodScore` (double): Current mood score (1-10)

**Returns:** `Future<List<Recommendation>>`

##### `getActivityRecommendations(double moodScore)`
Gets activity suggestions based on mood.

**Parameters:**
- `moodScore` (double): Current mood score (1-10)

**Returns:** `Future<List<Recommendation>>`

##### `getWellnessRecommendations(double moodScore)`
Gets wellness content based on mood.

**Parameters:**
- `moodScore` (double): Current mood score (1-10)

**Returns:** `Future<List<Recommendation>>`

### GamificationService
Manages XP, levels, and achievements.

#### Methods

##### `addXP(int amount)`
Adds XP to user's total.

**Parameters:**
- `amount` (int): XP amount to add

**Returns:** `Future<void>`

##### `getCurrentLevel()`
Gets user's current level.

**Returns:** `Future<int>`

##### `getXPProgress()`
Gets XP progress towards next level.

**Returns:** `Future<Map<String, int>>`

##### `unlockAchievement(String achievementId)`
Unlocks an achievement.

**Parameters:**
- `achievementId` (String): ID of achievement to unlock

**Returns:** `Future<void>`

##### `getAchievements()`
Gets all user achievements.

**Returns:** `Future<List<Achievement>>`

## Data Models

### MoodEntry
Represents a single mood entry.

```dart
class MoodEntry {
  final int mood;                    // Mood score (1-10)
  final String notes;               // Optional notes
  final DateTime timestamp;         // When entry was created
  final List<String> activities;    // Associated activities
}
```

### MoodPrediction
Result of AI mood analysis.

```dart
class MoodPrediction {
  final double predictedMood;       // Predicted mood (1-10)
  final double confidence;          // Confidence score (0-1)
  final List<String> factors;       // Key factors identified
  final List<String> suggestions;   // Personalized suggestions
}
```

### MoodInsight
AI-generated insight about mood patterns.

```dart
class MoodInsight {
  final String id;                  // Unique identifier
  final String type;                // 'trend', 'pattern', 'recommendation', 'warning'
  final String title;               // Insight title
  final String description;         // Detailed description
  final double confidence;          // Confidence score (0-1)
  final DateTime date;              // When insight was generated
  final bool actionable;            // Whether user can take action
  final String? actionText;         // Action button text
}
```

### Recommendation
Personalized content recommendation.

```dart
class Recommendation {
  final String id;                  // Unique identifier
  final String type;                // 'music', 'quote', 'activity', 'wellness'
  final String title;               // Recommendation title
  final String description;         // Description
  final String? imageUrl;           // Optional image URL
  final String? contentUrl;         // Optional content URL
  final double moodBoost;           // Expected mood boost (0-100%)
}
```

### Achievement
User achievement.

```dart
class Achievement {
  final String id;                  // Unique identifier
  final String title;               // Achievement title
  final String description;         // Description
  final String icon;                // Icon identifier
  final int xpReward;               // XP reward
  final bool unlocked;              // Whether unlocked
  final DateTime? unlockedAt;       // When unlocked
}
```

## Error Handling

All services include proper error handling with try-catch blocks and meaningful error messages.

### Common Error Types
- **NetworkError**: API communication issues
- **ValidationError**: Invalid input parameters
- **StorageError**: Local storage issues
- **AIError**: AI service failures

### Example Error Handling
```dart
try {
  final prediction = await AIService.predictMoodFromText(text);
  // Handle success
} catch (e) {
  if (e is NetworkError) {
    // Handle network issues
  } else if (e is ValidationError) {
    // Handle validation errors
  } else {
    // Handle other errors
  }
}
```

## Local Storage

The app uses SharedPreferences for local data storage.

### Stored Data
- User settings (theme, notifications)
- Mood entries
- XP and achievements
- App preferences

### Storage Keys
```dart
class StorageKeys {
  static const String theme = 'isDarkMode';
  static const String notifications = 'notificationsEnabled';
  static const String moodEntries = 'moodEntries';
  static const String userXP = 'userXP';
  static const String achievements = 'achievements';
}
```

## Performance Considerations

### Caching
- AI predictions are cached to avoid redundant API calls
- Recommendations are cached based on mood score
- User data is cached locally

### Optimization
- Lazy loading for large data sets
- Pagination for mood entries
- Image optimization for recommendations
- Efficient data structures

## Security

### Data Privacy
- All data stored locally
- No personal data sent to external servers
- Optional data sharing for AI improvements
- Clear privacy controls

### Input Validation
- All user inputs are validated
- Sanitization of text inputs
- Range validation for mood scores
- Type checking for all parameters

## Testing

### Unit Tests
Each service includes comprehensive unit tests.

```dart
// Example test
test('should predict mood from positive text', () async {
  final prediction = await AIService.predictMoodFromText('I feel great!');
  expect(prediction.predictedMood, greaterThan(7.0));
  expect(prediction.confidence, greaterThan(0.8));
});
```

### Integration Tests
End-to-end testing of service interactions.

### Mock Services
Mock implementations for testing without external dependencies.

## Future Enhancements

### Planned Features
- Real-time mood tracking
- Social features
- Advanced analytics
- Machine learning improvements
- Voice mood input
- Biometric integration

### API Improvements
- GraphQL support
- Real-time updates
- Advanced filtering
- Bulk operations
- Export capabilities

## Support

For API-related issues:
- Check the service documentation
- Review error messages
- Test with sample data
- Contact development team

## Changelog

### Version 1.0.0
- Initial API implementation
- Basic mood tracking
- AI mood analysis
- Recommendation system
- Gamification features
