# MoodScape Flutter - Production Build Guide

## Overview
MoodScape is a comprehensive mood tracking and wellness application built with Flutter. This guide covers production deployment, build processes, and documentation.

## Features
- **Mood Tracking**: Daily mood logging with 1-10 scale
- **AI Analysis**: Text-based mood prediction and insights
- **Personalized Recommendations**: Music, quotes, activities based on mood
- **Gamification**: XP, levels, and achievements system
- **Daily Check-ins**: Multi-step wellness assessment
- **Beautiful Themes**: Blue-orange gradient backgrounds
- **Cross-platform**: Web, Android, iOS, Windows, macOS, Linux

## Production Build Commands

### Web Build
```bash
# Development build
flutter run -d web-server --web-port 8083

# Production build
flutter build web --release

# Serve production build
cd build/web
python3 -m http.server 8080
```

### Android Build
```bash
# Debug APK
flutter build apk --debug

# Release APK
flutter build apk --release

# App Bundle (for Play Store)
flutter build appbundle --release
```

### iOS Build
```bash
# Debug build
flutter build ios --debug

# Release build
flutter build ios --release

# Archive for App Store
flutter build ipa --release
```

### Desktop Builds
```bash
# Windows
flutter build windows --release

# macOS
flutter build macos --release

# Linux
flutter build linux --release
```

## Deployment Options

### 1. Web Deployment
- **Firebase Hosting**: `firebase deploy`
- **Netlify**: Drag and drop `build/web` folder
- **Vercel**: Connect GitHub repository
- **GitHub Pages**: Push to `gh-pages` branch

### 2. Mobile App Stores
- **Google Play Store**: Upload `app-release.aab`
- **Apple App Store**: Upload `.ipa` file via Xcode

### 3. Desktop Distribution
- **Windows**: Distribute `.exe` from `build/windows/runner/Release/`
- **macOS**: Distribute `.app` from `build/macos/Build/Products/Release/`
- **Linux**: Distribute binary from `build/linux/x64/release/bundle/`

## Environment Configuration

### Production Environment Variables
Create `.env` file:
```env
API_BASE_URL=https://api.moodscape.com
ANALYTICS_KEY=your_analytics_key
SENTRY_DSN=your_sentry_dsn
```

### Build Configuration
Update `pubspec.yaml` for production:
```yaml
version: 1.0.0+1
environment:
  sdk: ^3.5.4
```

## Performance Optimization

### Web Optimization
- Enable tree shaking: `flutter build web --tree-shake-icons`
- Optimize assets: Compress images and fonts
- Use CDN for static assets
- Enable gzip compression

### Mobile Optimization
- Enable R8/ProGuard for Android
- Use App Bundle for smaller downloads
- Optimize images for different densities
- Enable code splitting

## Security Considerations

### API Security
- Use HTTPS for all API calls
- Implement proper authentication
- Validate all user inputs
- Use secure storage for sensitive data

### Data Privacy
- Comply with GDPR/CCPA
- Implement data encryption
- Provide data export/deletion
- Clear privacy policy

## Monitoring and Analytics

### Error Tracking
- Integrate Sentry for crash reporting
- Use Firebase Crashlytics
- Implement custom error handling

### Analytics
- Google Analytics for Flutter
- Firebase Analytics
- Custom event tracking

## Testing

### Unit Tests
```bash
flutter test
```

### Integration Tests
```bash
flutter test integration_test/
```

### Widget Tests
```bash
flutter test test/
```

## CI/CD Pipeline

### GitHub Actions Example
```yaml
name: Build and Deploy
on:
  push:
    branches: [main]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: subosito/flutter-action@v2
      - run: flutter pub get
      - run: flutter test
      - run: flutter build web --release
      - uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./build/web
```

## Troubleshooting

### Common Issues
1. **Flutter SDK version conflicts**: Update to latest stable
2. **Build failures**: Clean and rebuild
3. **Asset loading issues**: Check asset paths
4. **Performance issues**: Profile with Flutter Inspector

### Debug Commands
```bash
# Clean build
flutter clean
flutter pub get

# Check dependencies
flutter pub deps

# Analyze code
flutter analyze

# Check for issues
flutter doctor
```

## Release Checklist

- [ ] All tests passing
- [ ] Code reviewed
- [ ] Version bumped
- [ ] Changelog updated
- [ ] Assets optimized
- [ ] Security scan completed
- [ ] Performance tested
- [ ] Documentation updated
- [ ] Release notes prepared

## Support

For issues and questions:
- GitHub Issues: [Repository URL]
- Documentation: [Docs URL]
- Email: support@moodscape.com

## License

This project is licensed under the MIT License - see the LICENSE file for details.
