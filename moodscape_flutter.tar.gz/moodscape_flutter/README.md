# MoodScape Flutter App

A comprehensive mood tracking and wellness application built with Flutter, featuring AI-powered insights, personalized recommendations, and gamification elements.

## 🌟 Features

### Core Functionality
- **Daily Mood Tracking**: Log your mood on a 1-10 scale with notes
- **AI Mood Analysis**: Get AI-powered mood predictions from text input
- **Personalized Recommendations**: Music, quotes, and activities tailored to your mood
- **Gamification System**: Earn XP, level up, and unlock achievements
- **Daily Check-ins**: Multi-step wellness assessment
- **Beautiful Themes**: Blue-orange gradient backgrounds with light/dark mode support

### Technical Features
- **Cross-platform**: Web, Android, iOS, Windows, macOS, Linux
- **Responsive Design**: Works on all screen sizes
- **Offline Support**: Core features work without internet
- **Data Persistence**: Local storage with SharedPreferences
- **Modern UI**: Material Design 3 with custom theming

## 🚀 Quick Start

### Prerequisites
- Flutter SDK 3.5.4 or higher
- Dart 3.5.4 or higher
- Git

### Installation
```bash
# Clone the repository
git clone https://github.com/yourusername/moodscape_flutter.git
cd moodscape_flutter

# Install dependencies
flutter pub get

# Run the app
flutter run
```

### Web Development
```bash
# Run on web
flutter run -d web-server --web-port 8083

# Build for production
flutter build web --release
```

## 📱 Screenshots

### Home Screen
- Quick action buttons for easy navigation
- Daily check-in card
- Recent activity summary
- Beautiful gradient background

### Mood Tracker
- Interactive mood selection (1-10 scale)
- Notes and context input
- AI-powered recommendations
- Recent mood history

### AI Analysis
- Text-based mood prediction
- Confidence scoring
- Personalized suggestions
- Factor analysis

### Recommendations
- Music playlists based on mood
- Inspirational quotes
- Activity suggestions
- Wellness content

### Gamification
- XP and level system
- Achievement badges
- Progress tracking
- Streak counters

## 🏗️ Project Structure

```
lib/
├── main.dart                 # App entry point
├── screens/                  # UI screens
│   ├── home_screen.dart
│   ├── mood_tracker_screen.dart
│   ├── ai_prediction_screen.dart
│   ├── insights_screen.dart
│   ├── recommendations_screen.dart
│   ├── gamification_screen.dart
│   ├── daily_checkin_screen.dart
│   ├── profile_screen.dart
│   └── settings_screen.dart
├── services/                 # Business logic
│   ├── ai_service.dart
│   ├── recommendations_service.dart
│   ├── gamification_service.dart
│   └── api_service.dart
├── widgets/                  # Reusable components
│   ├── gradient_background.dart
│   ├── daily_quote_card.dart
│   ├── daily_checkin_card.dart
│   └── insight_card.dart
└── theme/                    # App theming
    └── app_theme.dart
```

## 🎨 Theming

The app features a beautiful blue-orange gradient theme system:

### Light Theme
- Primary: Dark Blue (#1E3A8A)
- Secondary: Light Orange (#FB923C)
- Background: Blue-orange gradient mixture
- Text: Dark blue-gray

### Dark Theme
- Primary: Dark Orange (#EA580C)
- Secondary: Light Orange (#FB923C)
- Background: Dark blue-orange gradient mixture
- Text: Light gray

## 🤖 AI Features

### Mood Prediction
- Analyzes text input for emotional content
- Provides confidence scores
- Identifies key factors
- Offers personalized suggestions

### Smart Recommendations
- Music playlists based on current mood
- Inspirational quotes
- Activity suggestions
- Wellness content

### Insights Generation
- Pattern recognition in mood data
- Trend analysis
- Personalized recommendations
- Achievement tracking

## 🎮 Gamification

### XP System
- Earn points for daily check-ins
- Bonus points for streaks
- Level progression
- Achievement unlocks

### Achievements
- Daily Streak Master
- Mood Tracker Pro
- AI Analysis Expert
- Wellness Champion

## 📊 Data & Privacy

### Local Storage
- All data stored locally using SharedPreferences
- No personal data sent to external servers
- User has full control over their data

### Privacy Features
- Optional data sharing for AI improvements
- Clear data export options
- Easy data deletion
- Transparent privacy policy

## 🛠️ Development

### Running Tests
```bash
# Unit tests
flutter test

# Integration tests
flutter test integration_test/

# Widget tests
flutter test test/
```

### Code Analysis
```bash
# Analyze code
flutter analyze

# Check for issues
flutter doctor
```

### Building for Production
```bash
# Web
flutter build web --release

# Android
flutter build apk --release

# iOS
flutter build ios --release
```

## 📦 Dependencies

### Core Dependencies
- `flutter`: SDK
- `shared_preferences`: Local storage
- `http`: API calls
- `intl`: Date formatting

### Development Dependencies
- `flutter_test`: Testing framework
- `flutter_lints`: Code analysis

## 🚀 Deployment

### Web Deployment
1. Build for production: `flutter build web --release`
2. Deploy `build/web` folder to your hosting service
3. Configure HTTPS and CDN

### Mobile Deployment
1. Build APK/AAB: `flutter build apk --release`
2. Upload to Google Play Store
3. Build IPA: `flutter build ipa --release`
4. Upload to Apple App Store

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📞 Support

- GitHub Issues: [Create an issue](https://github.com/yourusername/moodscape_flutter/issues)
- Email: support@moodscape.com
- Documentation: [Full docs](https://moodscape.com/docs)

## 🙏 Acknowledgments

- Flutter team for the amazing framework
- Material Design for UI inspiration
- Open source community for various packages
- Beta testers for valuable feedback

---

**Made with ❤️ and Flutter**