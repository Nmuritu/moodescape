#!/bin/bash

# MoodScape Flutter - Production Deployment Script
# This script builds and deploys the Flutter app for production

set -e  # Exit on any error

echo "🚀 MoodScape Flutter - Production Deployment"
echo "=============================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Flutter is installed
check_flutter() {
    print_status "Checking Flutter installation..."
    if ! command -v flutter &> /dev/null; then
        print_error "Flutter is not installed or not in PATH"
        print_status "Please install Flutter from https://flutter.dev/get-started"
        exit 1
    fi
    
    flutter_version=$(flutter --version | head -n 1)
    print_success "Flutter found: $flutter_version"
}

# Clean and get dependencies
setup_project() {
    print_status "Setting up project..."
    
    # Clean previous builds
    print_status "Cleaning previous builds..."
    flutter clean
    
    # Get dependencies
    print_status "Getting dependencies..."
    flutter pub get
    
    print_success "Project setup complete"
}

# Build for web
build_web() {
    print_status "Building for web..."
    
    # Build web release
    flutter build web --release --web-renderer html
    
    if [ $? -eq 0 ]; then
        print_success "Web build complete"
        print_status "Web build location: build/web/"
    else
        print_error "Web build failed"
        exit 1
    fi
}

# Build for Android
build_android() {
    print_status "Building for Android..."
    
    # Build APK
    flutter build apk --release
    
    if [ $? -eq 0 ]; then
        print_success "Android APK build complete"
        print_status "APK location: build/app/outputs/flutter-apk/app-release.apk"
    else
        print_error "Android build failed"
        exit 1
    fi
    
    # Build App Bundle
    print_status "Building Android App Bundle..."
    flutter build appbundle --release
    
    if [ $? -eq 0 ]; then
        print_success "Android App Bundle build complete"
        print_status "AAB location: build/app/outputs/bundle/release/app-release.aab"
    else
        print_error "Android App Bundle build failed"
        exit 1
    fi
}

# Build for iOS
build_ios() {
    print_status "Building for iOS..."
    
    # Build iOS
    flutter build ios --release
    
    if [ $? -eq 0 ]; then
        print_success "iOS build complete"
        print_status "iOS build location: build/ios/Release-iphoneos/"
    else
        print_error "iOS build failed"
        exit 1
    fi
    
    # Build IPA
    print_status "Building iOS IPA..."
    flutter build ipa --release
    
    if [ $? -eq 0 ]; then
        print_success "iOS IPA build complete"
        print_status "IPA location: build/ios/ipa/"
    else
        print_error "iOS IPA build failed"
        exit 1
    fi
}

# Build for desktop platforms
build_desktop() {
    print_status "Building for desktop platforms..."
    
    # Build Windows
    print_status "Building for Windows..."
    flutter build windows --release
    if [ $? -eq 0 ]; then
        print_success "Windows build complete"
        print_status "Windows build location: build/windows/runner/Release/"
    else
        print_warning "Windows build failed (may not be supported on this platform)"
    fi
    
    # Build macOS
    print_status "Building for macOS..."
    flutter build macos --release
    if [ $? -eq 0 ]; then
        print_success "macOS build complete"
        print_status "macOS build location: build/macos/Build/Products/Release/"
    else
        print_warning "macOS build failed (may not be supported on this platform)"
    fi
    
    # Build Linux
    print_status "Building for Linux..."
    flutter build linux --release
    if [ $? -eq 0 ]; then
        print_success "Linux build complete"
        print_status "Linux build location: build/linux/x64/release/bundle/"
    else
        print_warning "Linux build failed (may not be supported on this platform)"
    fi
}

# Run tests
run_tests() {
    print_status "Running tests..."
    
    # Run unit tests
    flutter test
    
    if [ $? -eq 0 ]; then
        print_success "All tests passed"
    else
        print_error "Tests failed"
        exit 1
    fi
}

# Analyze code
analyze_code() {
    print_status "Analyzing code..."
    
    flutter analyze
    
    if [ $? -eq 0 ]; then
        print_success "Code analysis passed"
    else
        print_warning "Code analysis found issues"
    fi
}

# Create deployment package
create_deployment_package() {
    print_status "Creating deployment package..."
    
    # Create deployment directory
    mkdir -p deployment
    
    # Copy web build
    if [ -d "build/web" ]; then
        cp -r build/web deployment/
        print_success "Web build copied to deployment/"
    fi
    
    # Copy Android builds
    if [ -f "build/app/outputs/flutter-apk/app-release.apk" ]; then
        cp build/app/outputs/flutter-apk/app-release.apk deployment/moodscape-android.apk
        print_success "Android APK copied to deployment/"
    fi
    
    if [ -f "build/app/outputs/bundle/release/app-release.aab" ]; then
        cp build/app/outputs/bundle/release/app-release.aab deployment/moodscape-android.aab
        print_success "Android AAB copied to deployment/"
    fi
    
    # Copy iOS builds
    if [ -d "build/ios/ipa" ]; then
        cp -r build/ios/ipa/* deployment/
        print_success "iOS builds copied to deployment/"
    fi
    
    # Create deployment info
    cat > deployment/DEPLOYMENT_INFO.md << EOF
# MoodScape Flutter - Deployment Package

Generated on: $(date)
Flutter Version: $(flutter --version | head -n 1)

## Contents

- Web build: Ready for deployment to any web hosting service
- Android APK: For direct installation or testing
- Android AAB: For Google Play Store upload
- iOS IPA: For App Store upload (requires Xcode)

## Deployment Instructions

### Web
1. Upload the contents of the web/ folder to your hosting service
2. Configure HTTPS and CDN
3. Set up proper caching headers

### Android
1. Upload the .aab file to Google Play Console
2. Or distribute the .apk file directly

### iOS
1. Use Xcode to upload the .ipa file to App Store Connect
2. Or use Application Loader

## Support
For deployment issues, check the PRODUCTION_BUILD.md file.
EOF
    
    print_success "Deployment package created in deployment/ directory"
}

# Main deployment function
main() {
    echo
    print_status "Starting MoodScape Flutter deployment process..."
    echo
    
    # Check Flutter installation
    check_flutter
    
    # Setup project
    setup_project
    
    # Run tests and analysis
    run_tests
    analyze_code
    
    # Build for all platforms
    build_web
    build_android
    build_ios
    build_desktop
    
    # Create deployment package
    create_deployment_package
    
    echo
    print_success "🎉 Deployment process completed successfully!"
    echo
    print_status "Deployment package created in: deployment/"
    print_status "Web build ready for hosting"
    print_status "Mobile builds ready for app stores"
    print_status "Desktop builds ready for distribution"
    echo
    print_status "Next steps:"
    print_status "1. Review the deployment package"
    print_status "2. Deploy web build to your hosting service"
    print_status "3. Upload mobile builds to app stores"
    print_status "4. Distribute desktop builds as needed"
    echo
}

# Parse command line arguments
case "${1:-all}" in
    "web")
        check_flutter
        setup_project
        run_tests
        analyze_code
        build_web
        ;;
    "android")
        check_flutter
        setup_project
        run_tests
        analyze_code
        build_android
        ;;
    "ios")
        check_flutter
        setup_project
        run_tests
        analyze_code
        build_ios
        ;;
    "desktop")
        check_flutter
        setup_project
        run_tests
        analyze_code
        build_desktop
        ;;
    "all"|"")
        main
        ;;
    "help"|"-h"|"--help")
        echo "MoodScape Flutter - Production Deployment Script"
        echo
        echo "Usage: $0 [platform]"
        echo
        echo "Platforms:"
        echo "  web       Build for web only"
        echo "  android   Build for Android only"
        echo "  ios       Build for iOS only"
        echo "  desktop   Build for desktop platforms only"
        echo "  all       Build for all platforms (default)"
        echo "  help      Show this help message"
        echo
        ;;
    *)
        print_error "Unknown platform: $1"
        print_status "Use '$0 help' for usage information"
        exit 1
        ;;
esac
