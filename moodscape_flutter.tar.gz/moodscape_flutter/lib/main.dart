import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'theme/app_theme.dart';
import 'screens/home_screen.dart';
import 'screens/mood_tracker_screen.dart';
import 'screens/insights_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/ai_prediction_screen.dart';
import 'screens/daily_checkin_screen.dart';
import 'screens/gamification_screen.dart';
import 'screens/recommendations_screen.dart';
import 'widgets/gradient_background.dart';

void main() {
  runApp(const MoodscapeApp());
}

class MoodscapeApp extends StatefulWidget {
  const MoodscapeApp({super.key});

  @override
  State<MoodscapeApp> createState() => _MoodscapeAppState();
}

class _MoodscapeAppState extends State<MoodscapeApp> {
  bool _isDarkMode = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isDarkMode = prefs.getBool('isDarkMode') ?? false;
      _isLoading = false;
    });
  }

  Future<void> _toggleTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
    await prefs.setBool('isDarkMode', _isDarkMode);
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return MaterialApp(
        home: Scaffold(
          body: Center(
            child: CircularProgressIndicator(
              color: _isDarkMode ? AppTheme.darkOrange : AppTheme.darkBlue,
            ),
          ),
        ),
      );
    }

    return MaterialApp(
      title: 'Moodscape',
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: _isDarkMode ? ThemeMode.dark : ThemeMode.light,
      home: MainNavigationScreen(
        key: mainNavigationKey,
        onThemeToggle: _toggleTheme,
        isDarkMode: _isDarkMode,
      ),
      routes: {
        '/ai_prediction': (context) => const AIPredictionScreen(),
        '/daily_checkin': (context) => const DailyCheckInScreen(),
        '/gamification': (context) => const GamificationScreen(),
        '/recommendations': (context) => const RecommendationsScreen(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  final VoidCallback onThemeToggle;
  final bool isDarkMode;

  const MainNavigationScreen({
    super.key,
    required this.onThemeToggle,
    required this.isDarkMode,
  });

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

// Global key to access the main navigation state
final GlobalKey<_MainNavigationScreenState> mainNavigationKey = GlobalKey<_MainNavigationScreenState>();

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;
  late final List<Widget> _screens;

  void _navigateToTab(int index) {
    print('Received navigation request for index: $index');
    setState(() {
      _currentIndex = index;
    });
    print('Current index updated to: $_currentIndex');
  }

  @override
  void initState() {
    super.initState();
    _initializeScreens();
  }

  void _initializeScreens() {
    _screens = [
      HomeScreen(onNavigateToTab: _navigateToTab),
      const MoodTrackerScreen(),
      const InsightsScreen(),
      const ProfileScreen(),
      SettingsScreen(
        onThemeToggle: widget.onThemeToggle,
        isDarkMode: widget.isDarkMode,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientBackground(
        isDarkMode: widget.isDarkMode,
        child: IndexedStack(
          index: _currentIndex,
          children: _screens,
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.mood_outlined),
            activeIcon: Icon(Icons.mood),
            label: 'Mood',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.analytics_outlined),
            activeIcon: Icon(Icons.analytics),
            label: 'Insights',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: 'Profile',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings_outlined),
            activeIcon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}