import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/ai_service.dart';

class AIPredictionScreen extends StatefulWidget {
  const AIPredictionScreen({super.key});

  @override
  State<AIPredictionScreen> createState() => _AIPredictionScreenState();
}

class _AIPredictionScreenState extends State<AIPredictionScreen> {
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  MoodPrediction? _prediction;

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  Future<void> _analyzeText() async {
    if (_textController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter some text to analyze')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _prediction = null;
    });

    try {
      final prediction = await AIService.predictMoodFromText(_textController.text);
      setState(() {
        _prediction = prediction;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error analyzing text: $e')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  String _getMoodEmoji(double mood) {
    if (mood >= 8) return '😊';
    if (mood >= 6) return '🙂';
    if (mood >= 4) return '😐';
    if (mood >= 2) return '😔';
    return '😢';
  }

  Color _getMoodColor(double mood) {
    if (mood >= 8) return Colors.green;
    if (mood >= 6) return Colors.lightGreen;
    if (mood >= 4) return Colors.orange;
    if (mood >= 2) return Colors.deepOrange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Mood Analysis'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [AppTheme.darkOrange.withOpacity(0.1), AppTheme.darkOrangeAccent.withOpacity(0.05)]
                      : [AppTheme.darkBlue.withOpacity(0.1), AppTheme.lightOrange.withOpacity(0.1)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'AI Mood Analysis',
                    style: theme.textTheme.headlineMedium?.copyWith(
                      color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Describe how you\'re feeling and get AI insights',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Input Section
            Text(
              'How are you feeling?',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 12),

            TextField(
              controller: _textController,
              maxLines: 6,
              decoration: InputDecoration(
                hintText: 'Tell me about your day, thoughts, or feelings...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: isDark ? AppTheme.darkOrangeSurface : AppTheme.darkBlueSurface,
              ),
            ),

            const SizedBox(height: 16),

            // Analyze Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _isLoading ? null : _analyzeText,
                icon: _isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.analytics),
                label: Text(_isLoading ? 'Analyzing...' : 'Analyze with AI'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Prediction Results
            if (_prediction != null) ...[
              Text(
                'AI Analysis Results',
                style: theme.textTheme.titleLarge,
              ),
              const SizedBox(height: 16),

              // Mood Score Card
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Predicted Mood',
                            style: theme.textTheme.titleMedium,
                          ),
                          Text(
                            '${_prediction!.confidence.toStringAsFixed(0)}% confidence',
                            style: theme.textTheme.bodyMedium?.copyWith(
                              color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Text(
                            _getMoodEmoji(_prediction!.predictedMood),
                            style: const TextStyle(fontSize: 48),
                          ),
                          const SizedBox(width: 16),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${_prediction!.predictedMood.toStringAsFixed(1)}/10',
                                style: theme.textTheme.headlineLarge?.copyWith(
                                  color: _getMoodColor(_prediction!.predictedMood),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                _getMoodLabel(_prediction!.predictedMood),
                                style: theme.textTheme.titleMedium,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // Factors
              if (_prediction!.factors.isNotEmpty) ...[
                Text(
                  'Analysis Factors',
                  style: theme.textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: _prediction!.factors.map((factor) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            Icon(
                              Icons.check_circle,
                              size: 16,
                              color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                            ),
                            const SizedBox(width: 8),
                            Expanded(child: Text(factor)),
                          ],
                        ),
                      )).toList(),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],

              // Suggestions
              Text(
                'AI Recommendations',
                style: theme.textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: _prediction!.suggestions.map((suggestion) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.lightbulb_outline,
                            size: 20,
                            color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              suggestion,
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                    )).toList(),
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // Action Buttons
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        _textController.clear();
                        setState(() {
                          _prediction = null;
                        });
                      },
                      icon: const Icon(Icons.refresh),
                      label: const Text('Analyze Again'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        // Navigate to mood tracker with predicted mood
                        Navigator.pop(context, _prediction!.predictedMood.round());
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Log This Mood'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _getMoodLabel(double mood) {
    if (mood >= 8) return 'Excellent';
    if (mood >= 6) return 'Good';
    if (mood >= 4) return 'Okay';
    if (mood >= 2) return 'Poor';
    return 'Very Poor';
  }
}
