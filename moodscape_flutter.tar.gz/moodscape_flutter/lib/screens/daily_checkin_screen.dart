import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/recommendations_service.dart';
import 'mood_tracker_screen.dart';
import 'recommendations_screen.dart';

class DailyCheckInScreen extends StatefulWidget {
  const DailyCheckInScreen({super.key});

  @override
  State<DailyCheckInScreen> createState() => _DailyCheckInScreenState();
}

class _DailyCheckInScreenState extends State<DailyCheckInScreen> {
  int _currentStep = 0;
  int? _selectedMood;
  String _selectedActivity = '';
  String _selectedQuote = '';
  bool _hasCheckedInToday = false;

  final List<String> _dailyActivities = [
    'Exercise',
    'Meditation',
    'Reading',
    'Socializing',
    'Creative work',
    'Nature walk',
    'Music listening',
    'Journaling',
  ];

  @override
  void initState() {
    super.initState();
    _checkIfAlreadyCheckedIn();
  }

  void _checkIfAlreadyCheckedIn() {
    // In a real app, check local storage or backend
    // For now, simulate random check-in status
    setState(() {
      _hasCheckedInToday = false; // Random().nextBool();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    if (_hasCheckedInToday) {
      return _buildAlreadyCheckedInView();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Check-In'),
        centerTitle: true,
        backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
        foregroundColor: Colors.white,
      ),
      body: PageView(
        controller: PageController(initialPage: _currentStep),
        onPageChanged: (index) {
          setState(() {
            _currentStep = index;
          });
        },
        children: [
          _buildMoodStep(),
          _buildActivityStep(),
          _buildQuoteStep(),
          _buildSummaryStep(),
        ],
      ),
      bottomNavigationBar: _buildBottomNavigation(),
    );
  }

  Widget _buildAlreadyCheckedInView() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final dailyQuote = RecommendationsService.getDailyQuote();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Check-In'),
        centerTitle: true,
        backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.check_circle,
                size: 80,
                color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
              ),
              const SizedBox(height: 24),
              Text(
                'Great job!',
                style: theme.textTheme.headlineMedium?.copyWith(
                  color: isDark ? AppTheme.darkText : AppTheme.lightText,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'You\'ve already completed your daily check-in today.',
                style: theme.textTheme.bodyLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Icon(
                        Icons.format_quote,
                        color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                        size: 32,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        '"${dailyQuote.text}"',
                        style: theme.textTheme.bodyLarge?.copyWith(
                          fontStyle: FontStyle.italic,
                          height: 1.5,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '— ${dailyQuote.author}',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const MoodTrackerScreen(),
                    ),
                  );
                },
                icon: const Icon(Icons.add_reaction),
                label: const Text('Log Another Mood'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMoodStep() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'How are you feeling today?',
            style: theme.textTheme.headlineMedium?.copyWith(
              color: isDark ? AppTheme.darkText : AppTheme.lightText,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Select your current mood to get personalized recommendations',
            style: theme.textTheme.bodyLarge?.copyWith(
              color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 1.2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemCount: 10,
              itemBuilder: (context, index) {
                final mood = index + 1;
                final isSelected = _selectedMood == mood;
                final emoji = _getMoodEmoji(mood);
                final label = _getMoodLabel(mood);

                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedMood = mood;
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: isSelected
                          ? (isDark ? AppTheme.darkOrange : AppTheme.darkBlue)
                          : (isDark ? AppTheme.darkOrangeSurface : AppTheme.darkBlueSurface),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected
                            ? (isDark ? AppTheme.darkOrangeAccent : AppTheme.darkBlueAccent)
                            : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          emoji,
                          style: const TextStyle(fontSize: 32),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '$mood',
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: isSelected
                                ? Colors.white
                                : (isDark ? AppTheme.darkOrangeText : AppTheme.darkBlueText),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          label,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: isSelected
                                ? Colors.white70
                                : (isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityStep() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'What would you like to do today?',
            style: theme.textTheme.headlineMedium?.copyWith(
              color: isDark ? AppTheme.darkText : AppTheme.lightText,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Choose an activity that matches your mood',
            style: theme.textTheme.bodyLarge?.copyWith(
              color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: ListView.builder(
              itemCount: _dailyActivities.length,
              itemBuilder: (context, index) {
                final activity = _dailyActivities[index];
                final isSelected = _selectedActivity == activity;

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: Icon(
                      _getActivityIcon(activity),
                      color: isSelected
                          ? (isDark ? AppTheme.darkOrange : AppTheme.darkBlue)
                          : (isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary),
                    ),
                    title: Text(activity),
                    trailing: isSelected
                        ? Icon(
                            Icons.check_circle,
                            color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                          )
                        : null,
                    onTap: () {
                      setState(() {
                        _selectedActivity = activity;
                      });
                    },
                    selected: isSelected,
                    selectedTileColor: isDark
                        ? AppTheme.darkOrangeSurface
                        : AppTheme.darkBlueSurface,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuoteStep() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final quotes = RecommendationsService.getQuotes(_selectedMood?.toDouble() ?? 5.0);

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Choose your daily inspiration',
            style: theme.textTheme.headlineMedium?.copyWith(
              color: isDark ? AppTheme.darkText : AppTheme.lightText,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Select a quote that resonates with you today',
            style: theme.textTheme.bodyLarge?.copyWith(
              color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: ListView.builder(
              itemCount: quotes.length,
              itemBuilder: (context, index) {
                final quote = quotes[index];
                final isSelected = _selectedQuote == quote.text;

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        _selectedQuote = quote.text;
                      });
                    },
                    borderRadius: BorderRadius.circular(12),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.format_quote,
                                color: isSelected
                                    ? (isDark ? AppTheme.darkOrange : AppTheme.darkBlue)
                                    : (isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary),
                                size: 20,
                              ),
                              const Spacer(),
                              if (isSelected)
                                Icon(
                                  Icons.check_circle,
                                  color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                                ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '"${quote.text}"',
                            style: theme.textTheme.bodyMedium?.copyWith(
                              fontStyle: FontStyle.italic,
                              height: 1.4,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '— ${quote.author}',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryStep() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Your Daily Check-In Summary',
            style: theme.textTheme.headlineMedium?.copyWith(
              color: isDark ? AppTheme.darkText : AppTheme.lightText,
            ),
          ),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  _SummaryItem(
                    icon: Icons.mood,
                    title: 'Mood',
                    value: '${_selectedMood}/10 - ${_getMoodLabel(_selectedMood!)}',
                    emoji: _getMoodEmoji(_selectedMood!),
                  ),
                  const Divider(),
                  _SummaryItem(
                    icon: Icons.sports,
                    title: 'Planned Activity',
                    value: _selectedActivity,
                    iconData: _getActivityIcon(_selectedActivity),
                  ),
                  const Divider(),
                  _SummaryItem(
                    icon: Icons.format_quote,
                    title: 'Daily Inspiration',
                    value: _selectedQuote,
                    isQuote: true,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Great job completing your daily check-in! This helps us provide better personalized recommendations.',
            style: theme.textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigation() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.scaffoldBackgroundColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          if (_currentStep > 0)
            TextButton(
              onPressed: () {
                setState(() {
                  _currentStep--;
                });
              },
              child: const Text('Previous'),
            )
          else
            const SizedBox.shrink(),
          Row(
            children: List.generate(4, (index) {
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: index <= _currentStep
                      ? (isDark ? AppTheme.darkOrange : AppTheme.darkBlue)
                      : Colors.grey.shade300,
                ),
              );
            }),
          ),
          if (_currentStep < 3)
            ElevatedButton(
              onPressed: _canProceed() ? () {
                setState(() {
                  _currentStep++;
                });
              } : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                foregroundColor: Colors.white,
              ),
              child: const Text('Next'),
            )
          else
            ElevatedButton(
              onPressed: _completeCheckIn,
              style: ElevatedButton.styleFrom(
                backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                foregroundColor: Colors.white,
              ),
              child: const Text('Complete'),
            ),
        ],
      ),
    );
  }

  bool _canProceed() {
    switch (_currentStep) {
      case 0:
        return _selectedMood != null;
      case 1:
        return _selectedActivity.isNotEmpty;
      case 2:
        return _selectedQuote.isNotEmpty;
      default:
        return true;
    }
  }

  void _completeCheckIn() {
    // Save check-in data
    final checkInData = {
      'mood': _selectedMood,
      'activity': _selectedActivity,
      'quote': _selectedQuote,
      'timestamp': DateTime.now().toIso8601String(),
      'date': DateTime.now().toIso8601String().split('T')[0],
    };

    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Daily check-in completed successfully!'),
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? AppTheme.darkOrange
            : AppTheme.darkBlue,
        action: SnackBarAction(
          label: 'Get Recommendations',
          textColor: Colors.white,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => RecommendationsScreen(
                  currentMood: _selectedMood!.toDouble(),
                ),
              ),
            );
          },
        ),
      ),
    );

    // Navigate back to home
    Navigator.pop(context);
  }

  String _getMoodEmoji(int mood) {
    const emojis = ['😢', '😔', '😐', '🙂', '😊', '😄', '🤩', '🥳', '🤯', '🌟'];
    return emojis[mood - 1];
  }

  String _getMoodLabel(int mood) {
    const labels = ['Very Sad', 'Sad', 'Neutral', 'Okay', 'Good', 'Happy', 'Great', 'Excellent', 'Amazing', 'Perfect'];
    return labels[mood - 1];
  }

  IconData _getActivityIcon(String activity) {
    switch (activity.toLowerCase()) {
      case 'exercise':
        return Icons.fitness_center;
      case 'meditation':
        return Icons.self_improvement;
      case 'reading':
        return Icons.menu_book;
      case 'socializing':
        return Icons.people;
      case 'creative work':
        return Icons.palette;
      case 'nature walk':
        return Icons.nature;
      case 'music listening':
        return Icons.music_note;
      case 'journaling':
        return Icons.edit;
      default:
        return Icons.star;
    }
  }
}

class _SummaryItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final String? emoji;
  final IconData? iconData;
  final bool isQuote;

  const _SummaryItem({
    required this.icon,
    required this.title,
    required this.value,
    this.emoji,
    this.iconData,
    this.isQuote = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          if (emoji != null)
            Text(emoji!, style: const TextStyle(fontSize: 24))
          else if (iconData != null)
            Icon(
              iconData,
              color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
              size: 24,
            )
          else
            Icon(
              icon,
              color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
              size: 24,
            ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
