import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/gamification_service.dart';

class GamificationScreen extends StatefulWidget {
  const GamificationScreen({super.key});

  @override
  State<GamificationScreen> createState() => _GamificationScreenState();
}

class _GamificationScreenState extends State<GamificationScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Progress & Achievements'),
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.trending_up), text: 'Progress'),
            Tab(icon: Icon(Icons.emoji_events), text: 'Achievements'),
            Tab(icon: Icon(Icons.flag), text: 'Goals'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildProgressTab(),
          _buildAchievementsTab(),
          _buildGoalsTab(),
        ],
      ),
    );
  }

  Widget _buildProgressTab() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final progress = GamificationService.getUserProgress();
    final levelProgress = GamificationService.getLevelProgress();
    final streakInfo = GamificationService.getStreakInfo();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Level Card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Level ${levelProgress['currentLevel']}',
                            style: theme.textTheme.headlineMedium?.copyWith(
                              color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '${levelProgress['currentXP']} XP',
                            style: theme.textTheme.bodyLarge?.copyWith(
                              color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          '${levelProgress['currentLevel']}',
                          style: theme.textTheme.headlineLarge?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  LinearProgressIndicator(
                    value: levelProgress['progressPercentage'],
                    backgroundColor: Colors.grey.shade300,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${levelProgress['xpProgress']}/${levelProgress['xpNeeded']} XP to next level',
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Stats Grid
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.5,
            children: [
              _StatCard(
                icon: Icons.local_fire_department,
                title: 'Streak',
                value: '${streakInfo['currentStreak']} days',
                subtitle: 'Best: ${streakInfo['longestStreak']} days',
                color: Colors.orange,
              ),
              _StatCard(
                icon: Icons.mood,
                title: 'Mood Entries',
                value: '${progress['totalMoodEntries']}',
                subtitle: 'Total logged',
                color: Colors.blue,
              ),
              _StatCard(
                icon: Icons.check_circle,
                title: 'Check-ins',
                value: '${progress['totalCheckIns']}',
                subtitle: 'Daily check-ins',
                color: Colors.green,
              ),
              _StatCard(
                icon: Icons.emoji_events,
                title: 'Achievements',
                value: '${GamificationService.getUnlockedAchievements().length}',
                subtitle: 'Unlocked',
                color: Colors.purple,
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Streak Progress
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.local_fire_department,
                        color: Colors.orange,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Streak Progress',
                        style: theme.textTheme.titleLarge,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  LinearProgressIndicator(
                    value: streakInfo['streakPercentage'],
                    backgroundColor: Colors.grey.shade300,
                    valueColor: const AlwaysStoppedAnimation<Color>(Colors.orange),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${streakInfo['currentStreak']}/${streakInfo['streakGoal']} days to complete streak goal',
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAchievementsTab() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final unlockedAchievements = GamificationService.getUnlockedAchievements();
    final lockedAchievements = GamificationService.getLockedAchievements();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Unlocked Achievements
          if (unlockedAchievements.isNotEmpty) ...[
            Text(
              'Unlocked Achievements',
              style: theme.textTheme.titleLarge?.copyWith(
                color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
              ),
            ),
            const SizedBox(height: 12),
            ...unlockedAchievements.map((achievement) => _AchievementCard(
              achievement: achievement,
              isUnlocked: true,
            )),
            const SizedBox(height: 24),
          ],

          // Locked Achievements
          Text(
            'Locked Achievements',
            style: theme.textTheme.titleLarge?.copyWith(
              color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
            ),
          ),
          const SizedBox(height: 12),
          ...lockedAchievements.map((achievement) => _AchievementCard(
            achievement: achievement,
            isUnlocked: false,
          )),
        ],
      ),
    );
  }

  Widget _buildGoalsTab() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final dailyGoals = GamificationService.getDailyGoals();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Daily Goals',
            style: theme.textTheme.titleLarge?.copyWith(
              color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Complete these goals to earn XP and maintain your streak!',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
            ),
          ),
          const SizedBox(height: 20),

          // Daily Goals
          ...dailyGoals.entries.map((entry) {
            final goalType = entry.key;
            final goal = entry.value;
            final isCompleted = goal['completed'] as bool;
            final current = goal['current'] as int;
            final target = goal['target'] as int;

            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isCompleted
                        ? Colors.green
                        : (isDark ? AppTheme.darkOrangeSurface : AppTheme.darkBlueSurface),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isCompleted ? Icons.check : _getGoalIcon(goalType),
                    color: isCompleted ? Colors.white : (isDark ? AppTheme.darkOrange : AppTheme.darkBlue),
                  ),
                ),
                title: Text(_getGoalTitle(goalType)),
                subtitle: Text('$current/$target completed'),
                trailing: isCompleted
                    ? Icon(Icons.check_circle, color: Colors.green)
                    : Icon(Icons.radio_button_unchecked, color: Colors.grey),
              ),
            );
          }),

          const SizedBox(height: 24),

          // Tips Card
          Card(
            color: isDark ? AppTheme.darkOrangeSurface : AppTheme.darkBlueSurface,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.lightbulb_outline,
                        color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Tips',
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '• Log your mood daily to maintain your streak\n'
                    '• Complete daily check-ins for bonus XP\n'
                    '• Use recommendations to discover new content\n'
                    '• Try AI analysis for personalized insights',
                    style: theme.textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getGoalIcon(String goalType) {
    switch (goalType) {
      case 'moodEntry':
        return Icons.mood;
      case 'checkIn':
        return Icons.check_circle;
      case 'recommendations':
        return Icons.recommend;
      default:
        return Icons.star;
    }
  }

  String _getGoalTitle(String goalType) {
    switch (goalType) {
      case 'moodEntry':
        return 'Log Your Mood';
      case 'checkIn':
        return 'Daily Check-in';
      case 'recommendations':
        return 'Use Recommendations';
      default:
        return 'Unknown Goal';
    }
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final String subtitle;
  final Color color;

  const _StatCard({
    required this.icon,
    required this.title,
    required this.value,
    required this.subtitle,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 24),
                const Spacer(),
                Text(
                  value,
                  style: theme.textTheme.titleLarge?.copyWith(
                    color: isDark ? AppTheme.darkOrangeText : AppTheme.darkBlueText,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: theme.textTheme.titleMedium,
            ),
            Text(
              subtitle,
              style: theme.textTheme.bodySmall?.copyWith(
                color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AchievementCard extends StatelessWidget {
  final Achievement achievement;
  final bool isUnlocked;

  const _AchievementCard({
    required this.achievement,
    required this.isUnlocked,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isUnlocked
                    ? (isDark ? AppTheme.darkOrange : AppTheme.darkBlue)
                    : Colors.grey.shade300,
                shape: BoxShape.circle,
              ),
              child: Text(
                achievement.icon,
                style: const TextStyle(fontSize: 24),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    achievement.title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: isUnlocked
                          ? (isDark ? AppTheme.darkOrangeText : AppTheme.darkBlueText)
                          : Colors.grey,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    achievement.description,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: isUnlocked
                          ? null
                          : Colors.grey,
                    ),
                  ),
                  if (isUnlocked) ...[
                    const SizedBox(height: 4),
                    Text(
                      '+${achievement.xpReward} XP',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            if (isUnlocked)
              Icon(
                Icons.check_circle,
                color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
              )
            else
              Icon(
                Icons.lock,
                color: Colors.grey,
              ),
          ],
        ),
      ),
    );
  }
}
