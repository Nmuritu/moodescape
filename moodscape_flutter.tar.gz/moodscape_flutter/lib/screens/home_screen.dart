import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'ai_prediction_screen.dart';
import 'recommendations_screen.dart';
import 'gamification_screen.dart';
import '../widgets/daily_quote_card.dart';
import '../widgets/daily_checkin_card.dart';
import '../widgets/gradient_background.dart';

class HomeScreen extends StatelessWidget {
  final Function(int)? onNavigateToTab;
  
  const HomeScreen({super.key, this.onNavigateToTab});

  void _navigateToMoodTracker(BuildContext context) {
    // Navigate to mood tracker tab (index 1)
    print('Navigating to Mood Tracker (index 1)');
    if (onNavigateToTab != null) {
      onNavigateToTab!(1);
    } else {
      print('ERROR: onNavigateToTab callback is null!');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Navigation not available')),
      );
    }
  }

  void _navigateToProfile(BuildContext context) {
    // Navigate to profile tab (index 3)
    print('Navigating to Profile (index 3)');
    if (onNavigateToTab != null) {
      onNavigateToTab!(3);
    } else {
      print('ERROR: onNavigateToTab callback is null!');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Navigation not available')),
      );
    }
  }

  void _navigateToSettings(BuildContext context) {
    // Navigate to settings tab (index 4)
    print('Navigating to Settings (index 4)');
    if (onNavigateToTab != null) {
      onNavigateToTab!(4);
    } else {
      print('ERROR: onNavigateToTab callback is null!');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Navigation not available')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Moodscape'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: isDark
                      ? [AppTheme.darkOrange.withOpacity(0.1), AppTheme.darkOrangeAccent.withOpacity(0.05)]
                      : [AppTheme.darkBlue.withOpacity(0.1), AppTheme.darkBlueAccent.withOpacity(0.05)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome to Moodscape!',
                    style: theme.textTheme.headlineMedium?.copyWith(
                      color: isDark ? AppTheme.darkText : AppTheme.lightText,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'How are you feeling today?',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: isDark ? AppTheme.darkTextSecondary : AppTheme.lightTextSecondary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Debug info
                  Text(
                    'Navigation callback: ${onNavigateToTab != null ? "Available" : "NULL"}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: onNavigateToTab != null ? Colors.green : Colors.red,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Test Navigation Button
            if (onNavigateToTab != null)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Text(
                        'Test Navigation',
                        style: theme.textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => _navigateToMoodTracker(context),
                              child: const Text('Test Mood Tracker'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => _navigateToProfile(context),
                              child: const Text('Test Profile'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => _navigateToSettings(context),
                              child: const Text('Test Settings'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

            const SizedBox(height: 24),

            // Quick Actions
            Text(
              'Quick Actions',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 16),

            Row(
              children: [
                Expanded(
                  child: _QuickActionCard(
                    icon: Icons.add_circle_outline,
                    title: 'Mood Logging',
                    subtitle: 'Track how you feel',
                    onTap: () => _navigateToMoodTracker(context),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _QuickActionCard(
                    icon: Icons.analytics_outlined,
                    title: 'AI Mood Analysis',
                    subtitle: 'Get AI mood insights',
                    onTap: () async {
                      final result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const AIPredictionScreen(),
                        ),
                      );
                      if (result != null) {
                        // Handle the predicted mood result
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('AI predicted mood: $result/10'),
                            backgroundColor: Theme.of(context).brightness == Brightness.dark
                                ? AppTheme.darkOrange
                                : AppTheme.darkBlue,
                          ),
                        );
                      }
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: _QuickActionCard(
                    icon: Icons.recommend,
                    title: 'Recommendations',
                    subtitle: 'Music, quotes & activities',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const RecommendationsScreen(),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _QuickActionCard(
                    icon: Icons.emoji_events,
                    title: 'Progress',
                    subtitle: 'View achievements',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const GamificationScreen(),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: _QuickActionCard(
                    icon: Icons.person_outline,
                    title: 'Profile',
                    subtitle: 'Manage your data',
                    onTap: () => _navigateToProfile(context),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _QuickActionCard(
                    icon: Icons.settings_outlined,
                    title: 'Settings',
                    subtitle: 'Customize app',
                    onTap: () => _navigateToSettings(context),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Daily Check-in Card
            const DailyCheckInCard(),

            const SizedBox(height: 24),

            // Daily Quote
            const DailyQuoteCard(),

            const SizedBox(height: 24),

            // Recent Activity
            Text(
              'Recent Activity',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 16),

            _RecentActivityCard(
              title: 'Last mood entry',
              subtitle: 'You logged a 7/10 mood yesterday',
              icon: Icons.mood,
            ),

            const SizedBox(height: 12),

            _RecentActivityCard(
              title: 'Weekly summary',
              subtitle: 'Your average mood this week is 6.5/10',
              icon: Icons.trending_up,
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _QuickActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Icon(
                icon,
                size: 32,
                color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
              ),
              const SizedBox(height: 8),
              Text(
                title,
                style: theme.textTheme.titleMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: theme.textTheme.bodySmall,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RecentActivityCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;

  const _RecentActivityCard({
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(
              icon,
              color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: theme.textTheme.titleMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: theme.textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
