import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/ai_service.dart';
import '../widgets/insight_card.dart';

class InsightsScreen extends StatefulWidget {
  const InsightsScreen({super.key});

  @override
  State<InsightsScreen> createState() => _InsightsScreenState();
}

class _InsightsScreenState extends State<InsightsScreen> {
  List<MoodInsight> _insights = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadInsights();
  }

  Future<void> _loadInsights() async {
    // Mock mood entries for demonstration
    final mockEntries = [
      MoodEntry(mood: 7, notes: 'Feeling good today', timestamp: DateTime.now().subtract(const Duration(days: 1))),
      MoodEntry(mood: 6, notes: 'Had a productive day', timestamp: DateTime.now().subtract(const Duration(days: 2))),
      MoodEntry(mood: 8, notes: 'Great mood after workout', timestamp: DateTime.now().subtract(const Duration(days: 3))),
      MoodEntry(mood: 5, notes: 'Feeling tired', timestamp: DateTime.now().subtract(const Duration(days: 4))),
      MoodEntry(mood: 7, notes: 'Good day overall', timestamp: DateTime.now().subtract(const Duration(days: 5))),
    ];

    final insights = await AIService.generateInsights(mockEntries);
    setState(() {
      _insights = insights;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Insights'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Weekly Summary
            _SummaryCard(
              title: 'This Week',
              averageMood: 6.8,
              totalEntries: 12,
              trend: 'up',
            ),

            const SizedBox(height: 16),

            // Monthly Summary
            _SummaryCard(
              title: 'This Month',
              averageMood: 6.2,
              totalEntries: 45,
              trend: 'stable',
            ),

            const SizedBox(height: 24),

            // Mood Distribution
            Text(
              'Mood Distribution',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 12),

            _MoodDistributionChart(),

            const SizedBox(height: 24),

            // Patterns
            Text(
              'Patterns & Insights',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 12),

            _PatternCard(
              icon: Icons.trending_up,
              title: 'Best Day',
              description: 'You feel happiest on Fridays',
              color: Colors.green,
            ),

            const SizedBox(height: 8),

            _PatternCard(
              icon: Icons.trending_down,
              title: 'Challenging Day',
              description: 'Mondays tend to be more difficult',
              color: Colors.orange,
            ),

            const SizedBox(height: 8),

            _PatternCard(
              icon: Icons.schedule,
              title: 'Peak Time',
              description: 'Your mood is highest in the evening',
              color: Colors.blue,
            ),

            const SizedBox(height: 24),

            // AI Insights
            Text(
              'AI Insights',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 12),

            if (_isLoading)
              const Center(child: CircularProgressIndicator())
            else if (_insights.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Icon(
                        Icons.analytics_outlined,
                        size: 48,
                        color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'No insights yet',
                        style: theme.textTheme.titleMedium,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Track more moods to get AI-powered insights',
                        style: theme.textTheme.bodyMedium,
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            else
              ..._insights.map((insight) => InsightCard(insight: insight)),

            const SizedBox(height: 24),

            // Goals
            Text(
              'Goals & Achievements',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 12),

            _GoalCard(
              title: 'Consistency Goal',
              description: 'Log mood daily for 30 days',
              progress: 0.6,
              current: 18,
              target: 30,
            ),

            const SizedBox(height: 8),

            _GoalCard(
              title: 'Positive Week',
              description: 'Average mood above 7 for a week',
              progress: 0.8,
              current: 5,
              target: 7,
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String title;
  final double averageMood;
  final int totalEntries;
  final String trend;

  const _SummaryCard({
    required this.title,
    required this.averageMood,
    required this.totalEntries,
    required this.trend,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    IconData trendIcon;
    Color trendColor;
    String trendText;

    switch (trend) {
      case 'up':
        trendIcon = Icons.trending_up;
        trendColor = Colors.green;
        trendText = 'Improving';
        break;
      case 'down':
        trendIcon = Icons.trending_down;
        trendColor = Colors.red;
        trendText = 'Declining';
        break;
      default:
        trendIcon = Icons.trending_flat;
        trendColor = Colors.grey;
        trendText = 'Stable';
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: theme.textTheme.titleLarge,
                ),
                Row(
                  children: [
                    Icon(trendIcon, color: trendColor, size: 20),
                    const SizedBox(width: 4),
                    Text(
                      trendText,
                      style: theme.textTheme.bodyMedium?.copyWith(color: trendColor),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Average Mood',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${averageMood.toStringAsFixed(1)}/10',
                        style: theme.textTheme.headlineMedium?.copyWith(
                          color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Total Entries',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '$totalEntries',
                        style: theme.textTheme.headlineMedium?.copyWith(
                          color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MoodDistributionChart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    // Sample data for mood distribution
    final moodData = [
      {'mood': 1, 'count': 1, 'percentage': 2.0},
      {'mood': 2, 'count': 2, 'percentage': 4.0},
      {'mood': 3, 'count': 3, 'percentage': 6.0},
      {'mood': 4, 'count': 5, 'percentage': 10.0},
      {'mood': 5, 'count': 8, 'percentage': 16.0},
      {'mood': 6, 'count': 12, 'percentage': 24.0},
      {'mood': 7, 'count': 10, 'percentage': 20.0},
      {'mood': 8, 'count': 6, 'percentage': 12.0},
      {'mood': 9, 'count': 2, 'percentage': 4.0},
      {'mood': 10, 'count': 1, 'percentage': 2.0},
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Mood Distribution (Last 30 days)',
                  style: theme.textTheme.titleMedium,
                ),
                Text(
                  '50 entries',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...moodData.map((data) {
              final mood = data['mood'] as int;
              final percentage = data['percentage'] as double;
              final count = data['count'] as int;

              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    SizedBox(
                      width: 30,
                      child: Text(
                        '$mood',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: LinearProgressIndicator(
                        value: percentage / 100,
                        backgroundColor: isDark
                            ? AppTheme.darkOrangeSurface
                            : AppTheme.darkBlueSurface,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 40,
                      child: Text(
                        '$count',
                        style: theme.textTheme.bodySmall,
                        textAlign: TextAlign.end,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
}

class _PatternCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final Color color;

  const _PatternCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: theme.textTheme.titleMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: theme.textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GoalCard extends StatelessWidget {
  final String title;
  final String description;
  final double progress;
  final int current;
  final int target;

  const _GoalCard({
    required this.title,
    required this.description,
    required this.progress,
    required this.current,
    required this.target,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: theme.textTheme.titleMedium,
                ),
                Text(
                  '$current/$target',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              description,
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: progress,
              backgroundColor: isDark
                  ? AppTheme.darkOrangeSurface
                  : AppTheme.darkBlueSurface,
              valueColor: AlwaysStoppedAnimation<Color>(
                isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
