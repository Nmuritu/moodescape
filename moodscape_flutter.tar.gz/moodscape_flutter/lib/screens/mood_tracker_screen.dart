import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/ai_service.dart';
import 'recommendations_screen.dart';

class MoodTrackerScreen extends StatefulWidget {
  const MoodTrackerScreen({super.key});

  @override
  State<MoodTrackerScreen> createState() => _MoodTrackerScreenState();
}

class _MoodTrackerScreenState extends State<MoodTrackerScreen> {
  int? _selectedMood;
  String _notes = '';
  final TextEditingController _notesController = TextEditingController();
  List<String> _recommendations = [];

  final List<Map<String, dynamic>> _moodOptions = [
    {'value': 1, 'emoji': '😢', 'label': 'Very Sad'},
    {'value': 2, 'emoji': '😔', 'label': 'Sad'},
    {'value': 3, 'emoji': '😐', 'label': 'Neutral'},
    {'value': 4, 'emoji': '🙂', 'label': 'Okay'},
    {'value': 5, 'emoji': '😊', 'label': 'Good'},
    {'value': 6, 'emoji': '😄', 'label': 'Happy'},
    {'value': 7, 'emoji': '🤩', 'label': 'Great'},
    {'value': 8, 'emoji': '🥳', 'label': 'Excellent'},
    {'value': 9, 'emoji': '🤯', 'label': 'Amazing'},
    {'value': 10, 'emoji': '🌟', 'label': 'Perfect'},
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mood Tracker'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Text(
              'How are you feeling right now?',
              style: theme.textTheme.headlineMedium,
            ),
            const SizedBox(height: 8),
            Text(
              'Select a mood from 1 to 10',
              style: theme.textTheme.bodyLarge?.copyWith(
                color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
              ),
            ),

            const SizedBox(height: 24),

            // Mood Selection Grid
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 1.5,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemCount: _moodOptions.length,
              itemBuilder: (context, index) {
                final mood = _moodOptions[index];
                final isSelected = _selectedMood == mood['value'];

                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedMood = mood['value'];
                      _recommendations = AIService.getMoodRecommendations(mood['value'].toDouble());
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: isSelected
                          ? (isDark ? AppTheme.darkOrange : AppTheme.darkBlue)
                          : (isDark ? AppTheme.darkOrangeSurface : AppTheme.darkBlueSurface),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected
                            ? (isDark ? AppTheme.darkOrange : AppTheme.darkBlue)
                            : (isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary)
                                .withOpacity(0.3),
                        width: 2,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          mood['emoji'],
                          style: const TextStyle(fontSize: 32),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${mood['value']}/10',
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: isSelected
                                ? Colors.white
                                : (isDark ? AppTheme.darkOrangeText : AppTheme.darkBlueText),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          mood['label'],
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: isSelected
                                ? Colors.white.withOpacity(0.9)
                                : (isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 32),

            // Notes Section
            Text(
              'Add a note (optional)',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 12),

            TextField(
              controller: _notesController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'How are you feeling? What\'s on your mind?',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: isDark ? AppTheme.darkOrangeSurface : AppTheme.darkBlueSurface,
              ),
              onChanged: (value) {
                setState(() {
                  _notes = value;
                });
              },
            ),

            const SizedBox(height: 24),

            // Recommendations Section
            if (_selectedMood != null && _recommendations.isNotEmpty) ...[
              Text(
                'AI Recommendations',
                style: theme.textTheme.titleLarge,
              ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.lightbulb_outline,
                            color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Based on your mood of $_selectedMood/10',
                            style: theme.textTheme.titleMedium,
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      ..._recommendations.map((recommendation) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              Icons.check_circle_outline,
                              size: 16,
                              color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                recommendation,
                                style: theme.textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                      )),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _selectedMood != null
                        ? () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => RecommendationsScreen(
                                  currentMood: _selectedMood!.toDouble(),
                                ),
                              ),
                            );
                          }
                        : null,
                    icon: const Icon(Icons.recommend),
                    label: const Text('Get Recommendations'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _selectedMood != null ? _saveMood : null,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: Text(
                      'Save Mood Entry',
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Recent Entries
            Text(
              'Recent Entries',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 12),

            _RecentMoodEntry(
              mood: 8,
              emoji: '🥳',
              notes: 'Had a great day at work!',
              date: 'Today, 2:30 PM',
            ),

            const SizedBox(height: 8),

            _RecentMoodEntry(
              mood: 6,
              emoji: '😄',
              notes: 'Feeling good after workout',
              date: 'Yesterday, 7:00 PM',
            ),
          ],
        ),
      ),
    );
  }

  void _saveMood() {
    if (_selectedMood == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please select your mood before saving.'),
          backgroundColor: Colors.red.shade600,
          action: SnackBarAction(
            label: 'OK',
            textColor: Colors.white,
            onPressed: () {},
          ),
        ),
      );
      return;
    }

    // Save mood entry with timestamp and notes
    final moodEntry = {
      'mood': _selectedMood,
      'notes': _notes,
      'timestamp': DateTime.now().toIso8601String(),
      'date': DateTime.now().toIso8601String().split('T')[0],
    };

    // In a real app, you would save this to a database or API
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Mood saved: $_selectedMood/10 - ${_getMoodLabel(_selectedMood!)}'),
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? AppTheme.darkOrange
            : AppTheme.darkBlue,
        action: SnackBarAction(
          label: 'View Insights',
          textColor: Colors.white,
          onPressed: () {
            // Navigate to insights screen
          },
        ),
      ),
    );

    // Show success dialog
    _showMoodSavedDialog();

    // Reset form
    setState(() {
      _selectedMood = null;
      _notes = '';
      _notesController.clear();
      _recommendations.clear();
    });
  }

  void _showMoodSavedDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.check_circle,
              color: Theme.of(context).brightness == Brightness.dark
                  ? AppTheme.darkOrange
                  : AppTheme.darkBlue,
            ),
            const SizedBox(width: 8),
            const Text('Mood Saved!'),
          ],
        ),
        content: const Text(
          'Your mood has been recorded. Keep tracking daily to see patterns and insights!',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Continue'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => RecommendationsScreen(
                    currentMood: _selectedMood!.toDouble(),
                  ),
                ),
              );
            },
            child: const Text('Get Recommendations'),
          ),
        ],
      ),
    );
  }

  String _getMoodLabel(int mood) {
    if (mood >= 8) return 'Excellent';
    if (mood >= 6) return 'Good';
    if (mood >= 4) return 'Okay';
    if (mood >= 2) return 'Poor';
    return 'Very Poor';
  }
}

class _RecentMoodEntry extends StatelessWidget {
  final int mood;
  final String emoji;
  final String notes;
  final String date;

  const _RecentMoodEntry({
    required this.mood,
    required this.emoji,
    required this.notes,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Text(
              emoji,
              style: const TextStyle(fontSize: 24),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        '$mood/10',
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        date,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    notes,
                    style: theme.textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
