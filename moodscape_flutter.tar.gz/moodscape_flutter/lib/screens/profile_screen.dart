import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Profile Header
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      child: const Icon(
                        Icons.person,
                        size: 50,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Moodscape User',
                      style: theme.textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'user@moodscape.app',
                      style: theme.textTheme.bodyLarge?.copyWith(
                        color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _StatItem(
                          value: '45',
                          label: 'Days Tracked',
                        ),
                        _StatItem(
                          value: '6.8',
                          label: 'Avg Mood',
                        ),
                        _StatItem(
                          value: '12',
                          label: 'Streak',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Profile Options
            _ProfileOption(
              icon: Icons.edit_outlined,
              title: 'Edit Profile',
              subtitle: 'Update your personal information',
              onTap: () {
                // Navigate to edit profile
              },
            ),

            _ProfileOption(
              icon: Icons.analytics_outlined,
              title: 'View Statistics',
              subtitle: 'See detailed mood analytics',
              onTap: () {
                // Navigate to detailed stats
              },
            ),

            _ProfileOption(
              icon: Icons.download_outlined,
              title: 'Export Data',
              subtitle: 'Download your mood data',
              onTap: () {
                // Export data functionality
              },
            ),

            _ProfileOption(
              icon: Icons.backup_outlined,
              title: 'Backup & Sync',
              subtitle: 'Sync data across devices',
              onTap: () {
                // Backup functionality
              },
            ),

            _ProfileOption(
              icon: Icons.privacy_tip_outlined,
              title: 'Privacy Settings',
              subtitle: 'Manage your data privacy',
              onTap: () {
                // Navigate to privacy settings
              },
            ),

            _ProfileOption(
              icon: Icons.help_outline,
              title: 'Help & Support',
              subtitle: 'Get help and contact support',
              onTap: () {
                // Navigate to help
              },
            ),

            _ProfileOption(
              icon: Icons.info_outline,
              title: 'About',
              subtitle: 'App version and information',
              onTap: () {
                _showAboutDialog(context);
              },
            ),

            const SizedBox(height: 24),

            // App Version
            Text(
              'Moodscape v1.0.0',
              style: theme.textTheme.bodySmall?.copyWith(
                color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: 'Moodscape',
      applicationVersion: '1.0.0',
      applicationIcon: Icon(
        Icons.mood,
        size: 48,
        color: Theme.of(context).brightness == Brightness.dark
            ? AppTheme.darkOrange
            : AppTheme.darkBlue,
      ),
      children: [
        const Text(
          'A beautiful mood tracking app built with Flutter. '
          'Track your emotions, gain insights, and improve your mental well-being.',
        ),
      ],
    );
  }
}

class _StatItem extends StatelessWidget {
  final String value;
  final String label;

  const _StatItem({
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Column(
      children: [
        Text(
          value,
          style: theme.textTheme.headlineMedium?.copyWith(
            color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
          ),
        ),
      ],
    );
  }
}

class _ProfileOption extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ProfileOption({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(
          icon,
          color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
        ),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
