import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/recommendations_service.dart';

class RecommendationsScreen extends StatefulWidget {
  final double? currentMood;

  const RecommendationsScreen({super.key, this.currentMood});

  @override
  State<RecommendationsScreen> createState() => _RecommendationsScreenState();
}

class _RecommendationsScreenState extends State<RecommendationsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  double _selectedMood = 5.0;
  List<MusicRecommendation> _musicRecommendations = [];
  List<Quote> _quotes = [];
  List<Activity> _activities = [];
  List<WellnessTip> _wellnessTips = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _selectedMood = widget.currentMood ?? 5.0;
    _loadRecommendations();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _loadRecommendations() {
    setState(() {
      _musicRecommendations = RecommendationsService.getMusicRecommendations(_selectedMood);
      _quotes = RecommendationsService.getQuotes(_selectedMood);
      _activities = RecommendationsService.getActivityRecommendations(_selectedMood);
      _wellnessTips = RecommendationsService.getWellnessTips(_selectedMood);
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Personalized Recommendations'),
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.music_note), text: 'Music'),
            Tab(icon: Icon(Icons.format_quote), text: 'Quotes'),
            Tab(icon: Icon(Icons.sports), text: 'Activities'),
            Tab(icon: Icon(Icons.favorite), text: 'Wellness'),
          ],
        ),
      ),
      body: Column(
        children: [
          // Mood Selector
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(
                  'Select your current mood for personalized recommendations',
                  style: theme.textTheme.titleMedium,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Text('1', style: theme.textTheme.bodySmall),
                    Expanded(
                      child: Slider(
                        value: _selectedMood,
                        min: 1,
                        max: 10,
                        divisions: 9,
                        onChanged: (value) {
                          setState(() {
                            _selectedMood = value;
                          });
                          _loadRecommendations();
                        },
                      ),
                    ),
                    Text('10', style: theme.textTheme.bodySmall),
                  ],
                ),
                Text(
                  'Mood: ${_selectedMood.round()}/10 - ${_getMoodLabel(_selectedMood)}',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          const Divider(),
          // Tab Content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildMusicTab(),
                _buildQuotesTab(),
                _buildActivitiesTab(),
                _buildWellnessTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMusicTab() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _musicRecommendations.length,
      itemBuilder: (context, index) {
        final recommendation = _musicRecommendations[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.music_note,
                      color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        recommendation.title,
                        style: theme.textTheme.titleLarge,
                      ),
                    ),
                    Chip(
                      label: Text('${(recommendation.moodBoost * 100).round()}% boost'),
                      backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      labelStyle: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  '${recommendation.artist} • ${recommendation.genre}',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  recommendation.description,
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),
                Text(
                  'Recommended Songs:',
                  style: theme.textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                ...recommendation.songs.map((song) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    children: [
                      Icon(
                        Icons.play_circle_outline,
                        size: 16,
                        color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      ),
                      const SizedBox(width: 8),
                      Expanded(child: Text(song)),
                    ],
                  ),
                )),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildQuotesTab() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _quotes.length,
      itemBuilder: (context, index) {
        final quote = _quotes[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.format_quote,
                  color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                  size: 32,
                ),
                const SizedBox(height: 8),
                Text(
                  '"${quote.text}"',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontStyle: FontStyle.italic,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '— ${quote.author}',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                      ),
                    ),
                    Chip(
                      label: Text(quote.category),
                      backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      labelStyle: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildActivitiesTab() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _activities.length,
      itemBuilder: (context, index) {
        final activity = _activities[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      _getActivityIcon(activity.category),
                      color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        activity.name,
                        style: theme.textTheme.titleLarge,
                      ),
                    ),
                    Chip(
                      label: Text('${(activity.moodBoost * 100).round()}% boost'),
                      backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      labelStyle: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  activity.description,
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _InfoChip(
                      icon: Icons.access_time,
                      label: activity.duration,
                    ),
                    const SizedBox(width: 8),
                    _InfoChip(
                      icon: Icons.trending_up,
                      label: activity.difficulty,
                    ),
                    const SizedBox(width: 8),
                    _InfoChip(
                      icon: Icons.category,
                      label: activity.category,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Starting: ${activity.name}'),
                          backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                        ),
                      );
                    },
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Start Activity'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildWellnessTab() {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _wellnessTips.length,
      itemBuilder: (context, index) {
        final tip = _wellnessTips[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.favorite,
                      color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        tip.title,
                        style: theme.textTheme.titleLarge,
                      ),
                    ),
                    Chip(
                      label: Text(tip.category),
                      backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      labelStyle: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  tip.content,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  IconData _getActivityIcon(String category) {
    switch (category.toLowerCase()) {
      case 'physical':
        return Icons.fitness_center;
      case 'social':
        return Icons.people;
      case 'creative':
        return Icons.palette;
      case 'learning':
        return Icons.school;
      case 'mindfulness':
        return Icons.self_improvement;
      case 'self-care':
        return Icons.spa;
      case 'support':
        return Icons.support_agent;
      case 'entertainment':
        return Icons.movie;
      default:
        return Icons.star;
    }
  }

  String _getMoodLabel(double mood) {
    if (mood >= 8) return 'Excellent';
    if (mood >= 6) return 'Good';
    if (mood >= 4) return 'Okay';
    if (mood >= 2) return 'Poor';
    return 'Very Poor';
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.darkOrangeSurface : AppTheme.darkBlueSurface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue),
          const SizedBox(width: 4),
          Text(
            label,
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}
