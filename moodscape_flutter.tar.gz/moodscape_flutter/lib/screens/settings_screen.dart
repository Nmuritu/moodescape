import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  final VoidCallback? onThemeToggle;
  final bool isDarkMode;

  const SettingsScreen({
    super.key,
    this.onThemeToggle,
    this.isDarkMode = false,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _dataSharingEnabled = true;
  String _selectedLanguage = 'English';
  String _selectedTheme = 'System';

  final List<String> _languages = ['English', 'Spanish', 'French', 'German'];
  final List<String> _themes = ['System', 'Light', 'Dark'];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Appearance Section
            _SectionHeader(title: 'Appearance'),
            Card(
              child: Column(
                children: [
                  _SettingsTile(
                    icon: Icons.palette_outlined,
                    title: 'Theme',
                    subtitle: widget.isDarkMode ? 'Dark Mode' : 'Light Mode',
                    trailing: Switch(
                      value: widget.isDarkMode,
                      onChanged: (value) {
                        widget.onThemeToggle?.call();
                      },
                    ),
                  ),
                  const Divider(height: 1),
                  _SettingsTile(
                    icon: Icons.language_outlined,
                    title: 'Language',
                    subtitle: _selectedLanguage,
                    trailing: DropdownButton<String>(
                      value: _selectedLanguage,
                      isExpanded: false,
                      underline: const SizedBox(),
                      items: _languages.map((String language) {
                        return DropdownMenuItem<String>(
                          value: language,
                          child: Text(language),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          setState(() {
                            _selectedLanguage = newValue;
                          });
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Notifications Section
            _SectionHeader(title: 'Notifications'),
            Card(
              child: Column(
                children: [
                  _SettingsTile(
                    icon: Icons.notifications_outlined,
                    title: 'Push Notifications',
                    subtitle: 'Daily mood reminders',
                    trailing: Switch(
                      value: _notificationsEnabled,
                      onChanged: (bool value) {
                        setState(() {
                          _notificationsEnabled = value;
                        });
                      },
                    ),
                  ),
                  const Divider(height: 1),
                  _SettingsTile(
                    icon: Icons.schedule_outlined,
                    title: 'Reminder Time',
                    subtitle: '7:00 PM',
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      // Show time picker
                    },
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Data & Privacy Section
            _SectionHeader(title: 'Data & Privacy'),
            Card(
              child: Column(
                children: [
                  _SettingsTile(
                    icon: Icons.share_outlined,
                    title: 'Data Sharing',
                    subtitle: 'Help improve the app',
                    trailing: Switch(
                      value: _dataSharingEnabled,
                      onChanged: (bool value) {
                        setState(() {
                          _dataSharingEnabled = value;
                        });
                      },
                    ),
                  ),
                  const Divider(height: 1),
                  _SettingsTile(
                    icon: Icons.security_outlined,
                    title: 'Privacy Policy',
                    subtitle: 'Read our privacy policy',
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      // Navigate to privacy policy
                    },
                  ),
                  const Divider(height: 1),
                  _SettingsTile(
                    icon: Icons.description_outlined,
                    title: 'Terms of Service',
                    subtitle: 'Read our terms of service',
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      // Navigate to terms of service
                    },
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // App Section
            _SectionHeader(title: 'App'),
            Card(
              child: Column(
                children: [
                  _SettingsTile(
                    icon: Icons.storage_outlined,
                    title: 'Storage',
                    subtitle: 'Manage app storage',
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      // Navigate to storage management
                    },
                  ),
                  const Divider(height: 1),
                  _SettingsTile(
                    icon: Icons.update_outlined,
                    title: 'Check for Updates',
                    subtitle: 'App version 1.0.0',
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      // Check for updates
                    },
                  ),
                  const Divider(height: 1),
                  _SettingsTile(
                    icon: Icons.refresh_outlined,
                    title: 'Reset Data',
                    subtitle: 'Clear all mood data',
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      _showResetDialog(context);
                    },
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Support Section
            _SectionHeader(title: 'Support'),
            Card(
              child: Column(
                children: [
                  _SettingsTile(
                    icon: Icons.help_outline,
                    title: 'Help Center',
                    subtitle: 'Get help and support',
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      // Navigate to help center
                    },
                  ),
                  const Divider(height: 1),
                  _SettingsTile(
                    icon: Icons.feedback_outlined,
                    title: 'Send Feedback',
                    subtitle: 'Share your thoughts',
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      // Open feedback form
                    },
                  ),
                  const Divider(height: 1),
                  _SettingsTile(
                    icon: Icons.star_outline,
                    title: 'Rate App',
                    subtitle: 'Rate us on the app store',
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      // Open app store rating
                    },
                  ),
                ],
              ),
            ),

            const SizedBox(height: 32),

            // App Version
            Center(
              child: Text(
                'Moodscape v1.0.0',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showResetDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Reset Data'),
          content: const Text(
            'Are you sure you want to reset all your mood data? This action cannot be undone.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                // Reset data logic here
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Data has been reset'),
                  ),
                );
              },
              child: Text(
                'Reset',
                style: TextStyle(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? AppTheme.darkOrange
                      : AppTheme.darkBlue,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;

  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: theme.textTheme.titleMedium?.copyWith(
          color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return ListTile(
      leading: Icon(
        icon,
        color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
      ),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: trailing,
      onTap: onTap,
    );
  }
}
