import 'dart:math';

class AIService {
  // Mock AI mood prediction based on text analysis
  static Future<MoodPrediction> predictMoodFromText(String text) async {
    // Simulate API delay
    await Future.delayed(const Duration(seconds: 2));
    
    final textLower = text.toLowerCase();
    double moodScore = 5.0;
    double confidence = 0.7;
    final factors = <String>[];
    final suggestions = <String>[];

    // Positive keywords
    final positiveWords = [
      'happy', 'great', 'amazing', 'wonderful', 'excellent', 'fantastic',
      'good', 'awesome', 'love', 'enjoy', 'excited', 'grateful', 'blessed',
      'successful', 'proud', 'confident', 'energetic', 'motivated'
    ];

    // Negative keywords
    final negativeWords = [
      'sad', 'terrible', 'awful', 'horrible', 'depressed', 'anxious',
      'worried', 'stressed', 'tired', 'exhausted', 'frustrated', 'angry',
      'lonely', 'scared', 'overwhelmed', 'hopeless', 'defeated'
    ];

    // Count positive and negative words
    int positiveCount = 0;
    int negativeCount = 0;

    for (final word in positiveWords) {
      if (textLower.contains(word)) {
        positiveCount++;
        factors.add('Positive language detected');
      }
    }

    for (final word in negativeWords) {
      if (textLower.contains(word)) {
        negativeCount++;
        factors.add('Negative language detected');
      }
    }

    // Calculate mood score based on word analysis
    if (positiveCount > negativeCount) {
      moodScore = 6.0 + (positiveCount * 0.5);
      confidence = 0.8;
    } else if (negativeCount > positiveCount) {
      moodScore = 4.0 - (negativeCount * 0.5);
      confidence = 0.8;
    }

    // Clamp mood score between 1 and 10
    moodScore = moodScore.clamp(1.0, 10.0);

    // Generate suggestions based on mood
    if (moodScore >= 8) {
      suggestions.addAll([
        'Great mood! Consider helping others or pursuing goals',
        'Share your positive energy with friends and family',
        'Use this energy to tackle challenging tasks'
      ]);
    } else if (moodScore >= 6) {
      suggestions.addAll([
        'Keep up the good work!',
        'Consider doing something you enjoy',
        'Connect with loved ones'
      ]);
    } else if (moodScore >= 4) {
      suggestions.addAll([
        'Try some light exercise or a walk',
        'Listen to your favorite music',
        'Practice deep breathing exercises'
      ]);
    } else {
      suggestions.addAll([
        'Consider reaching out to a friend or family member',
        'Try relaxation techniques like meditation',
        'Remember that this feeling is temporary',
        'Consider professional help if needed'
      ]);
    }

    // Add contextual suggestions
    if (textLower.contains('work') || textLower.contains('job')) {
      suggestions.add('Consider work-life balance strategies');
    }
    if (textLower.contains('sleep') || textLower.contains('tired')) {
      suggestions.add('Focus on improving sleep hygiene');
    }
    if (textLower.contains('relationship') || textLower.contains('friend')) {
      suggestions.add('Communication is key in relationships');
    }

    return MoodPrediction(
      predictedMood: moodScore,
      confidence: confidence,
      factors: factors,
      suggestions: suggestions,
    );
  }

  // Generate mood insights based on historical data
  static Future<List<MoodInsight>> generateInsights(List<MoodEntry> entries) async {
    if (entries.length < 3) return [];

    final insights = <MoodInsight>[];
    final recentEntries = entries.take(7).toList();
    
    // Calculate mood trend
    final moodValues = recentEntries.map((e) => e.mood).toList();
    final avgMood = moodValues.reduce((a, b) => a + b) / moodValues.length;
    final moodTrend = moodValues.last - moodValues.first;

    // Mood trend insight
    if (moodTrend > 1) {
      insights.add(MoodInsight(
        id: 'trend_${DateTime.now().millisecondsSinceEpoch}',
        type: InsightType.trend,
        title: 'Mood Improving!',
        description: 'Your mood has improved by ${moodTrend.toStringAsFixed(1)} points over the last week. Keep up the great work!',
        confidence: 0.8,
        date: DateTime.now(),
        actionable: true,
        actionText: 'Continue current activities',
      ));
    } else if (moodTrend < -1) {
      insights.add(MoodInsight(
        id: 'trend_${DateTime.now().millisecondsSinceEpoch}',
        type: InsightType.warning,
        title: 'Mood Declining',
        description: 'Your mood has decreased by ${moodTrend.abs().toStringAsFixed(1)} points recently. Consider reaching out for support.',
        confidence: 0.7,
        date: DateTime.now(),
        actionable: true,
        actionText: 'Try relaxation techniques',
      ));
    }

    // Average mood insight
    if (avgMood >= 7) {
      insights.add(MoodInsight(
        id: 'avg_${DateTime.now().millisecondsSinceEpoch}',
        type: InsightType.pattern,
        title: 'Consistently Positive',
        description: 'You\'ve been maintaining a positive mood with an average of ${avgMood.toStringAsFixed(1)}/10. Great job!',
        confidence: 0.9,
        date: DateTime.now(),
        actionable: true,
        actionText: 'Share your positivity',
      ));
    } else if (avgMood <= 4) {
      insights.add(MoodInsight(
        id: 'avg_${DateTime.now().millisecondsSinceEpoch}',
        type: InsightType.recommendation,
        title: 'Mood Support Needed',
        description: 'Your average mood is ${avgMood.toStringAsFixed(1)}/10. Consider seeking support or trying new activities.',
        confidence: 0.8,
        date: DateTime.now(),
        actionable: true,
        actionText: 'Explore mood-boosting activities',
      ));
    }

    // Activity correlation (if activities are tracked)
    final activityMoodMap = <String, List<double>>{};
    for (final entry in recentEntries) {
      for (final activity in entry.activities) {
        activityMoodMap.putIfAbsent(activity, () => []).add(entry.mood.toDouble());
      }
    }

    for (final entry in activityMoodMap.entries) {
      if (entry.value.length >= 2) {
        final avgMoodWithActivity = entry.value.reduce((a, b) => a + b) / entry.value.length;
        if (avgMoodWithActivity > avgMood + 1) {
          insights.add(MoodInsight(
            id: 'activity_${DateTime.now().millisecondsSinceEpoch}',
            type: InsightType.pattern,
            title: 'Activity Boost',
            description: '${entry.key} seems to boost your mood by ${(avgMoodWithActivity - avgMood).toStringAsFixed(1)} points on average.',
            confidence: 0.6,
            date: DateTime.now(),
            actionable: true,
            actionText: 'Do more ${entry.key.toLowerCase()}',
          ));
        }
      }
    }

    return insights;
  }

  // Get mood-based recommendations
  static List<String> getMoodRecommendations(double mood) {
    if (mood >= 8) {
      return [
        'Share your positive energy with others',
        'Take on a challenging project',
        'Help someone in need',
        'Document what made you feel great',
        'Plan something exciting for tomorrow'
      ];
    } else if (mood >= 6) {
      return [
        'Keep doing what you\'re doing',
        'Try a new hobby or activity',
        'Connect with friends or family',
        'Set a small goal for today',
        'Practice gratitude'
      ];
    } else if (mood >= 4) {
      return [
        'Take a short walk outside',
        'Listen to uplifting music',
        'Do some light exercise',
        'Practice deep breathing',
        'Call a friend or loved one'
      ];
    } else {
      return [
        'Be gentle with yourself',
        'Consider reaching out for support',
        'Try relaxation techniques',
        'Focus on basic self-care',
        'Remember this feeling is temporary'
      ];
    }
  }
}

class MoodPrediction {
  final double predictedMood;
  final double confidence;
  final List<String> factors;
  final List<String> suggestions;

  MoodPrediction({
    required this.predictedMood,
    required this.confidence,
    required this.factors,
    required this.suggestions,
  });
}

class MoodInsight {
  final String id;
  final InsightType type;
  final String title;
  final String description;
  final double confidence;
  final DateTime date;
  final bool actionable;
  final String? actionText;

  MoodInsight({
    required this.id,
    required this.type,
    required this.title,
    required this.description,
    required this.confidence,
    required this.date,
    this.actionable = false,
    this.actionText,
  });
}

enum InsightType {
  trend,
  pattern,
  recommendation,
  warning,
}

class MoodEntry {
  final int mood;
  final String notes;
  final DateTime timestamp;
  final List<String> activities;

  MoodEntry({
    required this.mood,
    required this.notes,
    required this.timestamp,
    this.activities = const [],
  });
}
