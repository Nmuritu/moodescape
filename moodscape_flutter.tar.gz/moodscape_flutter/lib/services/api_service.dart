import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://localhost:5000'; // Python backend URL
  
  // Headers for API requests
  static Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  // Save mood entry
  static Future<Map<String, dynamic>> saveMoodEntry({
    required int mood,
    String? notes,
    DateTime? timestamp,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/mood'),
        headers: _headers,
        body: jsonEncode({
          'mood': mood,
          'notes': notes ?? '',
          'timestamp': timestamp?.toIso8601String() ?? DateTime.now().toIso8601String(),
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to save mood entry: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error saving mood entry: $e');
    }
  }

  // Get mood entries
  static Future<List<Map<String, dynamic>>> getMoodEntries({
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      String url = '$baseUrl/api/mood';
      List<String> queryParams = [];
      
      if (startDate != null) {
        queryParams.add('start_date=${startDate.toIso8601String()}');
      }
      if (endDate != null) {
        queryParams.add('end_date=${endDate.toIso8601String()}');
      }
      
      if (queryParams.isNotEmpty) {
        url += '?${queryParams.join('&')}';
      }

      final response = await http.get(
        Uri.parse(url),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['entries'] ?? []);
      } else {
        throw Exception('Failed to get mood entries: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error getting mood entries: $e');
    }
  }

  // Get mood insights
  static Future<Map<String, dynamic>> getMoodInsights({
    String period = 'week',
  }) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/insights?period=$period'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get mood insights: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error getting mood insights: $e');
    }
  }

  // Get AI prediction
  static Future<Map<String, dynamic>> getAIPrediction({
    required List<int> recentMoods,
    String? additionalData,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/predict'),
        headers: _headers,
        body: jsonEncode({
          'recent_moods': recentMoods,
          'additional_data': additionalData,
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get AI prediction: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error getting AI prediction: $e');
    }
  }

  // Health check
  static Future<bool> checkBackendHealth() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/health'),
        headers: _headers,
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }
}
