import 'dart:math';

class GamificationService {
  static const int maxStreakDays = 30;
  static const int maxLevel = 100;
  static const int xpPerMoodEntry = 10;
  static const int xpPerCheckIn = 25;
  static const int xpPerRecommendation = 5;

  // User progress data
  static Map<String, dynamic> _userProgress = {
    'level': 1,
    'xp': 0,
    'streak': 0,
    'totalMoodEntries': 0,
    'totalCheckIns': 0,
    'achievements': <String>[],
    'lastActivityDate': null,
  };

  // Achievement definitions
  static final List<Achievement> _achievements = [
    Achievement(
      id: 'first_mood',
      title: 'First Steps',
      description: 'Log your first mood entry',
      icon: '🎯',
      xpReward: 50,
      requirement: {'moodEntries': 1},
    ),
    Achievement(
      id: 'week_streak',
      title: 'Consistent Tracker',
      description: 'Log mood for 7 consecutive days',
      icon: '🔥',
      xpReward: 100,
      requirement: {'streak': 7},
    ),
    Achievement(
      id: 'month_streak',
      title: 'Mood Master',
      description: 'Log mood for 30 consecutive days',
      icon: '👑',
      xpReward: 500,
      requirement: {'streak': 30},
    ),
    Achievement(
      id: 'mood_explorer',
      title: 'Mood Explorer',
      description: 'Log 50 different mood entries',
      icon: '🗺️',
      xpReward: 200,
      requirement: {'moodEntries': 50},
    ),
    Achievement(
      id: 'recommendation_lover',
      title: 'Recommendation Lover',
      description: 'Use 20 recommendations',
      icon: '💡',
      xpReward: 150,
      requirement: {'recommendations': 20},
    ),
    Achievement(
      id: 'daily_checker',
      title: 'Daily Checker',
      description: 'Complete 10 daily check-ins',
      icon: '✅',
      xpReward: 300,
      requirement: {'checkIns': 10},
    ),
    Achievement(
      id: 'mood_analyst',
      title: 'Mood Analyst',
      description: 'Use AI analysis 10 times',
      icon: '🤖',
      xpReward: 250,
      requirement: {'aiAnalysis': 10},
    ),
    Achievement(
      id: 'wellness_warrior',
      title: 'Wellness Warrior',
      description: 'Complete 100 mood entries',
      icon: '🛡️',
      xpReward: 1000,
      requirement: {'moodEntries': 100},
    ),
  ];

  // Get user progress
  static Map<String, dynamic> getUserProgress() {
    return Map.from(_userProgress);
  }

  // Add XP and check for level up
  static Map<String, dynamic> addXP(int amount, String source) {
    _userProgress['xp'] += amount;
    
    // Check for level up
    int newLevel = _calculateLevel(_userProgress['xp']);
    bool leveledUp = newLevel > _userProgress['level'];
    
    if (leveledUp) {
      _userProgress['level'] = newLevel;
    }

    // Update activity counters
    switch (source) {
      case 'moodEntry':
        _userProgress['totalMoodEntries']++;
        break;
      case 'checkIn':
        _userProgress['totalCheckIns']++;
        break;
      case 'recommendation':
        _userProgress['recommendations'] = (_userProgress['recommendations'] ?? 0) + 1;
        break;
      case 'aiAnalysis':
        _userProgress['aiAnalysis'] = (_userProgress['aiAnalysis'] ?? 0) + 1;
        break;
    }

    // Update streak
    _updateStreak();

    // Check for new achievements
    List<Achievement> newAchievements = _checkAchievements();

    return {
      'leveledUp': leveledUp,
      'newLevel': newLevel,
      'newAchievements': newAchievements,
      'progress': getUserProgress(),
    };
  }

  // Calculate level based on XP
  static int _calculateLevel(int xp) {
    // Level formula: level = sqrt(xp / 100) + 1
    return (sqrt(xp / 100) + 1).floor().clamp(1, maxLevel);
  }

  // Update streak based on last activity
  static void _updateStreak() {
    DateTime now = DateTime.now();
    DateTime? lastActivity = _userProgress['lastActivityDate'] != null
        ? DateTime.parse(_userProgress['lastActivityDate'])
        : null;

    if (lastActivity == null) {
      _userProgress['streak'] = 1;
    } else {
      int daysDifference = now.difference(lastActivity).inDays;
      
      if (daysDifference == 0) {
        // Same day, keep streak
        return;
      } else if (daysDifference == 1) {
        // Next day, increment streak
        _userProgress['streak']++;
      } else {
        // Gap in days, reset streak
        _userProgress['streak'] = 1;
      }
    }

    _userProgress['lastActivityDate'] = now.toIso8601String();
  }

  // Check for new achievements
  static List<Achievement> _checkAchievements() {
    List<Achievement> newAchievements = [];

    for (Achievement achievement in _achievements) {
      if (!_userProgress['achievements'].contains(achievement.id)) {
        bool unlocked = _checkAchievementRequirement(achievement);
        
        if (unlocked) {
          _userProgress['achievements'].add(achievement.id);
          _userProgress['xp'] += achievement.xpReward;
          newAchievements.add(achievement);
        }
      }
    }

    return newAchievements;
  }

  // Check if achievement requirement is met
  static bool _checkAchievementRequirement(Achievement achievement) {
    Map<String, int> requirements = achievement.requirement;
    
    for (String key in requirements.keys) {
      int required = requirements[key]!;
      int current = _userProgress[key] ?? 0;
      
      if (current < required) {
        return false;
      }
    }
    
    return true;
  }

  // Get progress towards next level
  static Map<String, dynamic> getLevelProgress() {
    int currentLevel = _userProgress['level'];
    int currentXP = _userProgress['xp'];
    
    int xpForCurrentLevel = _getXPForLevel(currentLevel);
    int xpForNextLevel = _getXPForLevel(currentLevel + 1);
    
    int xpNeeded = xpForNextLevel - xpForCurrentLevel;
    int xpProgress = currentXP - xpForCurrentLevel;
    
    double progressPercentage = (xpProgress / xpNeeded).clamp(0.0, 1.0);
    
    return {
      'currentLevel': currentLevel,
      'currentXP': currentXP,
      'xpForNextLevel': xpForNextLevel,
      'xpNeeded': xpNeeded,
      'xpProgress': xpProgress,
      'progressPercentage': progressPercentage,
    };
  }

  // Get XP required for a specific level
  static int _getXPForLevel(int level) {
    if (level <= 1) return 0;
    return ((level - 1) * (level - 1) * 100).toInt();
  }

  // Get streak information
  static Map<String, dynamic> getStreakInfo() {
    int currentStreak = _userProgress['streak'];
    int longestStreak = _userProgress['longestStreak'] ?? currentStreak;
    
    if (currentStreak > longestStreak) {
      _userProgress['longestStreak'] = currentStreak;
      longestStreak = currentStreak;
    }
    
    return {
      'currentStreak': currentStreak,
      'longestStreak': longestStreak,
      'streakGoal': maxStreakDays,
      'streakPercentage': (currentStreak / maxStreakDays).clamp(0.0, 1.0),
    };
  }

  // Get all achievements
  static List<Achievement> getAllAchievements() {
    return List.from(_achievements);
  }

  // Get unlocked achievements
  static List<Achievement> getUnlockedAchievements() {
    return _achievements.where((achievement) {
      return _userProgress['achievements'].contains(achievement.id);
    }).toList();
  }

  // Get locked achievements
  static List<Achievement> getLockedAchievements() {
    return _achievements.where((achievement) {
      return !_userProgress['achievements'].contains(achievement.id);
    }).toList();
  }

  // Get progress towards specific achievement
  static Map<String, dynamic> getAchievementProgress(Achievement achievement) {
    Map<String, int> requirements = achievement.requirement;
    Map<String, dynamic> progress = {};
    
    for (String key in requirements.keys) {
      int required = requirements[key]!;
      int current = _userProgress[key] ?? 0;
      
      progress[key] = {
        'current': current,
        'required': required,
        'percentage': (current / required).clamp(0.0, 1.0),
        'completed': current >= required,
      };
    }
    
    return progress;
  }

  // Reset user progress (for testing)
  static void resetProgress() {
    _userProgress = {
      'level': 1,
      'xp': 0,
      'streak': 0,
      'totalMoodEntries': 0,
      'totalCheckIns': 0,
      'achievements': <String>[],
      'lastActivityDate': null,
    };
  }

  // Get daily goals
  static Map<String, dynamic> getDailyGoals() {
    return {
      'moodEntry': {
        'target': 1,
        'current': _userProgress['dailyMoodEntries'] ?? 0,
        'completed': (_userProgress['dailyMoodEntries'] ?? 0) >= 1,
      },
      'checkIn': {
        'target': 1,
        'current': _userProgress['dailyCheckIns'] ?? 0,
        'completed': (_userProgress['dailyCheckIns'] ?? 0) >= 1,
      },
      'recommendations': {
        'target': 3,
        'current': _userProgress['dailyRecommendations'] ?? 0,
        'completed': (_userProgress['dailyRecommendations'] ?? 0) >= 3,
      },
    };
  }

  // Complete daily goal
  static void completeDailyGoal(String goalType) {
    switch (goalType) {
      case 'moodEntry':
        _userProgress['dailyMoodEntries'] = (_userProgress['dailyMoodEntries'] ?? 0) + 1;
        break;
      case 'checkIn':
        _userProgress['dailyCheckIns'] = (_userProgress['dailyCheckIns'] ?? 0) + 1;
        break;
      case 'recommendations':
        _userProgress['dailyRecommendations'] = (_userProgress['dailyRecommendations'] ?? 0) + 1;
        break;
    }
  }
}

class Achievement {
  final String id;
  final String title;
  final String description;
  final String icon;
  final int xpReward;
  final Map<String, int> requirement;

  Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.xpReward,
    required this.requirement,
  });
}
