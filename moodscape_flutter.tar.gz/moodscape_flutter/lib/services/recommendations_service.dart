import 'dart:math';

class RecommendationsService {
  // Music recommendations based on mood
  static List<MusicRecommendation> getMusicRecommendations(double mood) {
    if (mood >= 8) {
      return [
        MusicRecommendation(
          title: "Happy Vibes",
          artist: "Various Artists",
          genre: "Upbeat Pop",
          description: "High-energy songs to keep your positive mood going",
          songs: [
            "Happy - Pharrell Williams",
            "Good as Hell - Lizzo",
            "Can't Stop the Feeling - Justin Timberlake",
            "Shake It Off - Taylor Swift",
            "Walking on Sunshine - Katrina and the Waves"
          ],
          moodBoost: 0.9,
        ),
        MusicRecommendation(
          title: "Motivational Anthems",
          artist: "Various Artists",
          genre: "Inspirational",
          description: "Powerful songs to fuel your success",
          songs: [
            "Eye of the Tiger - Survivor",
            "Stronger - Kanye West",
            "I Will Survive - Gloria Gaynor",
            "Roar - Katy Perry",
            "Fight Song - Rachel Platten"
          ],
          moodBoost: 0.8,
        ),
      ];
    } else if (mood >= 6) {
      return [
        MusicRecommendation(
          title: "Feel Good Classics",
          artist: "Various Artists",
          genre: "Classic Rock",
          description: "Timeless songs to maintain your good mood",
          songs: [
            "Don't Stop Me Now - Queen",
            "Here Comes the Sun - The Beatles",
            "Three Little Birds - Bob Marley",
            "I'm a Believer - The Monkees",
            "Sweet Caroline - Neil Diamond"
          ],
          moodBoost: 0.7,
        ),
        MusicRecommendation(
          title: "Chill Vibes",
          artist: "Various Artists",
          genre: "Indie/Alternative",
          description: "Relaxing yet uplifting music",
          songs: [
            "Riptide - Vance Joy",
            "Ho Hey - The Lumineers",
            "Home - Edward Sharpe & The Magnetic Zeros",
            "Best Day of My Life - American Authors",
            "Count on Me - Bruno Mars"
          ],
          moodBoost: 0.6,
        ),
      ];
    } else if (mood >= 4) {
      return [
        MusicRecommendation(
          title: "Gentle Uplift",
          artist: "Various Artists",
          genre: "Soft Rock",
          description: "Gentle songs to gradually improve your mood",
          songs: [
            "Lean on Me - Bill Withers",
            "What a Wonderful World - Louis Armstrong",
            "You've Got a Friend - James Taylor",
            "Bridge Over Troubled Water - Simon & Garfunkel",
            "Imagine - John Lennon"
          ],
          moodBoost: 0.5,
        ),
        MusicRecommendation(
          title: "Calming Melodies",
          artist: "Various Artists",
          genre: "Ambient/New Age",
          description: "Peaceful music to help you find balance",
          songs: [
            "Weightless - Marconi Union",
            "Clair de Lune - Debussy",
            "River Flows in You - Yiruma",
            "Spiegel im Spiegel - Arvo Pärt",
            "Gymnopédie No. 1 - Erik Satie"
          ],
          moodBoost: 0.4,
        ),
      ];
    } else {
      return [
        MusicRecommendation(
          title: "Healing Sounds",
          artist: "Various Artists",
          genre: "Therapeutic",
          description: "Comforting music to help you through difficult times",
          songs: [
            "Hallelujah - Leonard Cohen",
            "Fix You - Coldplay",
            "The Climb - Miley Cyrus",
            "Rise Up - Andra Day",
            "You Are Not Alone - Michael Jackson"
          ],
          moodBoost: 0.3,
        ),
        MusicRecommendation(
          title: "Nature Sounds",
          artist: "Various Artists",
          genre: "Ambient",
          description: "Natural sounds to promote relaxation and healing",
          songs: [
            "Ocean Waves - Nature Sounds",
            "Rainforest Ambience - Nature Sounds",
            "Mountain Stream - Nature Sounds",
            "Birds Singing - Nature Sounds",
            "Thunderstorm - Nature Sounds"
          ],
          moodBoost: 0.2,
        ),
      ];
    }
  }

  // Inspirational quotes based on mood
  static List<Quote> getQuotes(double mood) {
    if (mood >= 8) {
      return [
        Quote(
          text: "The only way to do great work is to love what you do.",
          author: "Steve Jobs",
          category: "Motivation",
        ),
        Quote(
          text: "Success is not final, failure is not fatal: it is the courage to continue that counts.",
          author: "Winston Churchill",
          category: "Success",
        ),
        Quote(
          text: "The future belongs to those who believe in the beauty of their dreams.",
          author: "Eleanor Roosevelt",
          category: "Dreams",
        ),
        Quote(
          text: "Your limitation—it's only your imagination.",
          author: "Unknown",
          category: "Inspiration",
        ),
      ];
    } else if (mood >= 6) {
      return [
        Quote(
          text: "Life is what happens to you while you're busy making other plans.",
          author: "John Lennon",
          category: "Life",
        ),
        Quote(
          text: "The way to get started is to quit talking and begin doing.",
          author: "Walt Disney",
          category: "Action",
        ),
        Quote(
          text: "Don't be afraid to give up the good to go for the great.",
          author: "John D. Rockefeller",
          category: "Growth",
        ),
        Quote(
          text: "Innovation distinguishes between a leader and a follower.",
          author: "Steve Jobs",
          category: "Innovation",
        ),
      ];
    } else if (mood >= 4) {
      return [
        Quote(
          text: "It is during our darkest moments that we must focus to see the light.",
          author: "Aristotle",
          category: "Hope",
        ),
        Quote(
          text: "The only impossible journey is the one you never begin.",
          author: "Tony Robbins",
          category: "Courage",
        ),
        Quote(
          text: "In the middle of difficulty lies opportunity.",
          author: "Albert Einstein",
          category: "Opportunity",
        ),
        Quote(
          text: "You are never too old to set another goal or to dream a new dream.",
          author: "C.S. Lewis",
          category: "Dreams",
        ),
      ];
    } else {
      return [
        Quote(
          text: "This too shall pass.",
          author: "Persian Proverb",
          category: "Comfort",
        ),
        Quote(
          text: "You are braver than you believe, stronger than you seem, and smarter than you think.",
          author: "A.A. Milne",
          category: "Encouragement",
        ),
        Quote(
          text: "The sun will rise and we will try again.",
          author: "Twenty One Pilots",
          category: "Hope",
        ),
        Quote(
          text: "You are not alone in this. You are not alone in the world.",
          author: "Unknown",
          category: "Support",
        ),
        Quote(
          text: "Every storm runs out of rain.",
          author: "Maya Angelou",
          category: "Resilience",
        ),
      ];
    }
  }

  // Activity recommendations based on mood
  static List<Activity> getActivityRecommendations(double mood) {
    if (mood >= 8) {
      return [
        Activity(
          name: "Dance Party",
          description: "Put on your favorite music and dance like nobody's watching",
          duration: "15-30 minutes",
          difficulty: "Easy",
          moodBoost: 0.9,
          category: "Physical",
        ),
        Activity(
          name: "Creative Project",
          description: "Start a new art project, write, or create something beautiful",
          duration: "30-60 minutes",
          difficulty: "Medium",
          moodBoost: 0.8,
          category: "Creative",
        ),
        Activity(
          name: "Help Others",
          description: "Volunteer, help a friend, or do something kind for someone",
          duration: "30+ minutes",
          difficulty: "Easy",
          moodBoost: 0.9,
          category: "Social",
        ),
        Activity(
          name: "Adventure Planning",
          description: "Plan your next trip or adventure",
          duration: "20-40 minutes",
          difficulty: "Easy",
          moodBoost: 0.7,
          category: "Planning",
        ),
      ];
    } else if (mood >= 6) {
      return [
        Activity(
          name: "Nature Walk",
          description: "Take a walk in nature and appreciate the beauty around you",
          duration: "20-45 minutes",
          difficulty: "Easy",
          moodBoost: 0.7,
          category: "Physical",
        ),
        Activity(
          name: "Call a Friend",
          description: "Reach out to someone you care about",
          duration: "15-30 minutes",
          difficulty: "Easy",
          moodBoost: 0.6,
          category: "Social",
        ),
        Activity(
          name: "Learn Something New",
          description: "Watch a tutorial, read an article, or try a new skill",
          duration: "20-40 minutes",
          difficulty: "Medium",
          moodBoost: 0.6,
          category: "Learning",
        ),
        Activity(
          name: "Organize Your Space",
          description: "Tidy up your room or workspace",
          duration: "15-30 minutes",
          difficulty: "Easy",
          moodBoost: 0.5,
          category: "Productivity",
        ),
      ];
    } else if (mood >= 4) {
      return [
        Activity(
          name: "Gentle Exercise",
          description: "Do some light stretching, yoga, or a short walk",
          duration: "10-20 minutes",
          difficulty: "Easy",
          moodBoost: 0.5,
          category: "Physical",
        ),
        Activity(
          name: "Listen to Music",
          description: "Put on some calming or uplifting music",
          duration: "15-30 minutes",
          difficulty: "Easy",
          moodBoost: 0.4,
          category: "Relaxation",
        ),
        Activity(
          name: "Write in a Journal",
          description: "Express your thoughts and feelings on paper",
          duration: "10-20 minutes",
          difficulty: "Easy",
          moodBoost: 0.4,
          category: "Emotional",
        ),
        Activity(
          name: "Take a Warm Bath",
          description: "Relax in a warm bath with some soothing music",
          duration: "20-30 minutes",
          difficulty: "Easy",
          moodBoost: 0.6,
          category: "Self-Care",
        ),
      ];
    } else {
      return [
        Activity(
          name: "Deep Breathing",
          description: "Practice deep breathing exercises for 5-10 minutes",
          duration: "5-10 minutes",
          difficulty: "Easy",
          moodBoost: 0.3,
          category: "Mindfulness",
        ),
        Activity(
          name: "Reach Out for Support",
          description: "Call a friend, family member, or mental health professional",
          duration: "15-30 minutes",
          difficulty: "Easy",
          moodBoost: 0.4,
          category: "Support",
        ),
        Activity(
          name: "Watch Something Uplifting",
          description: "Watch a funny movie, inspiring video, or feel-good content",
          duration: "30-60 minutes",
          difficulty: "Easy",
          moodBoost: 0.3,
          category: "Entertainment",
        ),
        Activity(
          name: "Practice Gratitude",
          description: "Write down three things you're grateful for",
          duration: "5-10 minutes",
          difficulty: "Easy",
          moodBoost: 0.4,
          category: "Mindfulness",
        ),
      ];
    }
  }

  // Wellness content and tips
  static List<WellnessTip> getWellnessTips(double mood) {
    if (mood >= 8) {
      return [
        WellnessTip(
          title: "Maintain Your Positive Energy",
          content: "Your positive mood is a gift! Share it with others and use this energy to tackle challenging tasks.",
          category: "Maintenance",
        ),
        WellnessTip(
          title: "Set New Goals",
          content: "Use your high mood to set ambitious but achievable goals for yourself.",
          category: "Goal Setting",
        ),
        WellnessTip(
          title: "Practice Gratitude",
          content: "Take time to appreciate what's going well in your life right now.",
          category: "Mindfulness",
        ),
      ];
    } else if (mood >= 6) {
      return [
        WellnessTip(
          title: "Build on Your Good Mood",
          content: "Engage in activities that naturally boost your mood further.",
          category: "Enhancement",
        ),
        WellnessTip(
          title: "Connect with Others",
          content: "Your positive energy can be contagious - share it with friends and family.",
          category: "Social",
        ),
        WellnessTip(
          title: "Stay Hydrated",
          content: "Good mood often comes with good energy - make sure you're staying hydrated.",
          category: "Health",
        ),
      ];
    } else if (mood >= 4) {
      return [
        WellnessTip(
          title: "Small Steps Matter",
          content: "Even small positive actions can help improve your mood gradually.",
          category: "Progress",
        ),
        WellnessTip(
          title: "Be Patient with Yourself",
          content: "It's okay to have neutral days - they're part of the natural rhythm of life.",
          category: "Self-Compassion",
        ),
        WellnessTip(
          title: "Focus on What You Can Control",
          content: "Concentrate on the things you can influence rather than what you can't.",
          category: "Mindfulness",
        ),
      ];
    } else {
      return [
        WellnessTip(
          title: "You're Not Alone",
          content: "Many people experience difficult times. It's okay to ask for help.",
          category: "Support",
        ),
        WellnessTip(
          title: "This Feeling is Temporary",
          content: "Even though it feels overwhelming now, this difficult period will pass.",
          category: "Hope",
        ),
        WellnessTip(
          title: "Professional Help is Available",
          content: "Consider reaching out to a mental health professional if you're struggling.",
          category: "Resources",
        ),
        WellnessTip(
          title: "Small Acts of Self-Care",
          content: "Even small acts of self-care can make a difference in how you feel.",
          category: "Self-Care",
        ),
      ];
    }
  }

  // Get a random quote for daily inspiration
  static Quote getDailyQuote() {
    final quotes = [
      Quote(text: "Today is a new opportunity to be better than yesterday.", author: "Unknown", category: "Daily"),
      Quote(text: "Every morning is a fresh start.", author: "Unknown", category: "Daily"),
      Quote(text: "You have the power to make today amazing.", author: "Unknown", category: "Daily"),
      Quote(text: "Small progress is still progress.", author: "Unknown", category: "Daily"),
      Quote(text: "Be kind to yourself today.", author: "Unknown", category: "Daily"),
    ];
    return quotes[Random().nextInt(quotes.length)];
  }
}

class MusicRecommendation {
  final String title;
  final String artist;
  final String genre;
  final String description;
  final List<String> songs;
  final double moodBoost;

  MusicRecommendation({
    required this.title,
    required this.artist,
    required this.genre,
    required this.description,
    required this.songs,
    required this.moodBoost,
  });
}

class Quote {
  final String text;
  final String author;
  final String category;

  Quote({
    required this.text,
    required this.author,
    required this.category,
  });
}

class Activity {
  final String name;
  final String description;
  final String duration;
  final String difficulty;
  final double moodBoost;
  final String category;

  Activity({
    required this.name,
    required this.description,
    required this.duration,
    required this.difficulty,
    required this.moodBoost,
    required this.category,
  });
}

class WellnessTip {
  final String title;
  final String content;
  final String category;

  WellnessTip({
    required this.title,
    required this.content,
    required this.category,
  });
}
