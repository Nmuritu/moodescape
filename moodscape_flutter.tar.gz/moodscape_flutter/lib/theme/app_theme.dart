import 'package:flutter/material.dart';

class AppTheme {
  // Light Theme - Blue and Orange Mixture
  static const Color darkBlue = Color(0xFF1E3A8A); // Primary dark blue
  static const Color darkBlueLight = Color(0xFF3B82F6); // Lighter blue
  static const Color darkBlueAccent = Color(0xFF60A5FA); // Accent blue
  static const Color lightOrange = Color(0xFFFB923C); // Light orange
  static const Color lightOrangeAccent = Color(0xFFFDBA74); // Light orange accent
  
  // Light theme background colors (blue-orange mixture)
  static const Color lightBackgroundPrimary = Color(0xFFE6F2FF); // Soft blue base
  static const Color lightBackgroundSecondary = Color(0xFFFFF4E6); // Soft orange base
  static const Color lightSurface = Color(0xFFF8FAFC); // Light surface with blue tint
  static const Color lightSurfaceVariant = Color(0xFFF1F5F9); // Subtle blue-gray
  
  // Light theme text colors
  static const Color lightText = Color(0xFF1E293B); // Dark text
  static const Color lightTextSecondary = Color(0xFF64748B); // Secondary text

  // Dark Theme - Dark Blue and Orange Mixture
  static const Color darkOrange = Color(0xFFEA580C); // Primary dark orange
  static const Color darkOrangeLight = Color(0xFFFB923C); // Lighter orange
  static const Color darkOrangeAccent = Color(0xFFFDBA74); // Accent orange
  
  // Dark theme background colors (dark blue-orange mixture)
  static const Color darkBackgroundPrimary = Color(0xFF0F172A); // Deep blue base
  static const Color darkBackgroundSecondary = Color(0xFF1A0F0A); // Deep orange base
  static const Color darkSurface = Color(0xFF1E293B); // Dark surface with blue tint
  static const Color darkSurfaceVariant = Color(0xFF334155); // Darker blue-gray
  
  // Dark theme text colors
  static const Color darkText = Color(0xFFF1F5F9); // Light text
  static const Color darkTextSecondary = Color(0xFF94A3B8); // Secondary text

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: const ColorScheme.light(
        primary: darkBlue,
        primaryContainer: darkBlueLight,
        secondary: lightOrange,
        tertiary: lightOrangeAccent,
        surface: lightSurface,
        background: lightBackgroundPrimary,
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onTertiary: Colors.white,
        onSurface: lightText,
        onBackground: lightText,
        onSurfaceVariant: lightTextSecondary,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: darkBlue,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardTheme(
        color: darkBlueSurface,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: darkBlue,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        ),
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          color: lightText,
          fontSize: 32,
          fontWeight: FontWeight.bold,
        ),
        headlineMedium: TextStyle(
          color: lightText,
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),
        titleLarge: TextStyle(
          color: lightText,
          fontSize: 20,
          fontWeight: FontWeight.w600,
        ),
        bodyLarge: TextStyle(
          color: lightText,
          fontSize: 16,
        ),
        bodyMedium: TextStyle(
          color: lightTextSecondary,
          fontSize: 14,
        ),
      ),
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: const ColorScheme.dark(
        primary: darkOrange,
        primaryContainer: darkOrangeLight,
        secondary: darkOrangeAccent,
        surface: darkSurface,
        background: darkBackgroundPrimary,
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: darkText,
        onBackground: darkText,
        onSurfaceVariant: darkTextSecondary,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: darkOrange,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardTheme(
        color: darkOrangeSurface,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: darkOrange,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        ),
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          color: darkText,
          fontSize: 32,
          fontWeight: FontWeight.bold,
        ),
        headlineMedium: TextStyle(
          color: darkText,
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),
        titleLarge: TextStyle(
          color: darkText,
          fontSize: 20,
          fontWeight: FontWeight.w600,
        ),
        bodyLarge: TextStyle(
          color: darkText,
          fontSize: 16,
        ),
        bodyMedium: TextStyle(
          color: darkTextSecondary,
          fontSize: 14,
        ),
      ),
    );
  }
}
