import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/gamification_service.dart';
import '../screens/daily_checkin_screen.dart';
import '../screens/gamification_screen.dart';

class DailyCheckInCard extends StatelessWidget {
  const DailyCheckInCard({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    
    // Get progress data safely
    Map<String, dynamic> progress;
    Map<String, dynamic> streakInfo;
    
    try {
      progress = GamificationService.getUserProgress();
      streakInfo = GamificationService.getStreakInfo();
    } catch (e) {
      // Fallback data if service fails
      progress = {
        'level': 1,
        'xp': 0,
        'streak': 0,
      };
      streakInfo = {
        'currentStreak': 0,
        'longestStreak': 0,
      };
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.check_circle_outline,
                  color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Daily Check-In',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${streakInfo['currentStreak']} day streak',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'Complete your daily check-in to maintain your streak and earn XP!',
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      try {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const DailyCheckInScreen(),
                          ),
                        );
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Error opening daily check-in: $e'),
                            backgroundColor: Colors.red,
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Start Check-In'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      side: BorderSide(
                        color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      try {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const GamificationScreen(),
                          ),
                        );
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Error opening progress view: $e'),
                            backgroundColor: Colors.red,
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.trending_up),
                    label: const Text('View Progress'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
