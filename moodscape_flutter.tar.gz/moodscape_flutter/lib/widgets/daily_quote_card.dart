import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/recommendations_service.dart';

class DailyQuoteCard extends StatelessWidget {
  const DailyQuoteCard({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final dailyQuote = RecommendationsService.getDailyQuote();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.format_quote,
                  color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Daily Inspiration',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: isDark ? AppTheme.darkOrange : AppTheme.darkBlue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              '"${dailyQuote.text}"',
              style: theme.textTheme.bodyLarge?.copyWith(
                fontStyle: FontStyle.italic,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '— ${dailyQuote.author}',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
