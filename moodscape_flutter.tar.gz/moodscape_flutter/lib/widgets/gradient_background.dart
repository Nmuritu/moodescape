import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class GradientBackground extends StatelessWidget {
  final Widget child;
  final bool isDarkMode;

  const GradientBackground({
    super.key,
    required this.child,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isDarkMode
              ? [
                  AppTheme.darkBackgroundPrimary,
                  AppTheme.darkBackgroundSecondary,
                  AppTheme.darkBackgroundPrimary,
                ]
              : [
                  AppTheme.lightBackgroundPrimary,
                  AppTheme.lightBackgroundSecondary,
                  AppTheme.lightBackgroundPrimary,
                ],
          stops: const [0.0, 0.5, 1.0],
        ),
      ),
      child: child,
    );
  }
}

class AnimatedGradientBackground extends StatefulWidget {
  final Widget child;
  final bool isDarkMode;

  const AnimatedGradientBackground({
    super.key,
    required this.child,
    required this.isDarkMode,
  });

  @override
  State<AnimatedGradientBackground> createState() => _AnimatedGradientBackgroundState();
}

class _AnimatedGradientBackgroundState extends State<AnimatedGradientBackground>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    );
    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));
    _controller.repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: widget.isDarkMode
                  ? [
                      Color.lerp(
                        AppTheme.darkBackgroundPrimary,
                        AppTheme.darkBackgroundSecondary,
                        _animation.value,
                      )!,
                      Color.lerp(
                        AppTheme.darkBackgroundSecondary,
                        AppTheme.darkBackgroundPrimary,
                        _animation.value,
                      )!,
                      Color.lerp(
                        AppTheme.darkBackgroundPrimary,
                        AppTheme.darkBackgroundSecondary,
                        _animation.value,
                      )!,
                    ]
                  : [
                      Color.lerp(
                        AppTheme.lightBackgroundPrimary,
                        AppTheme.lightBackgroundSecondary,
                        _animation.value,
                      )!,
                      Color.lerp(
                        AppTheme.lightBackgroundSecondary,
                        AppTheme.lightBackgroundPrimary,
                        _animation.value,
                      )!,
                      Color.lerp(
                        AppTheme.lightBackgroundPrimary,
                        AppTheme.lightBackgroundSecondary,
                        _animation.value,
                      )!,
                    ],
              stops: const [0.0, 0.5, 1.0],
            ),
          ),
          child: widget.child,
        );
      },
    );
  }
}

class RadialGradientBackground extends StatelessWidget {
  final Widget child;
  final bool isDarkMode;

  const RadialGradientBackground({
    super.key,
    required this.child,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.topLeft,
          radius: 1.5,
          colors: isDarkMode
              ? [
                  AppTheme.darkBackgroundPrimary,
                  AppTheme.darkBackgroundSecondary,
                  AppTheme.darkBackgroundPrimary,
                ]
              : [
                  AppTheme.lightBackgroundPrimary,
                  AppTheme.lightBackgroundSecondary,
                  AppTheme.lightBackgroundPrimary,
                ],
          stops: const [0.0, 0.6, 1.0],
        ),
      ),
      child: child,
    );
  }
}
