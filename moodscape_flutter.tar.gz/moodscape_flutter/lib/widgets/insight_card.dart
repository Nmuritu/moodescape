import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/ai_service.dart';

class InsightCard extends StatelessWidget {
  final MoodInsight insight;

  const InsightCard({super.key, required this.insight});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    IconData icon;
    Color color;

    switch (insight.type) {
      case InsightType.trend:
        icon = Icons.trending_up;
        color = Colors.green;
        break;
      case InsightType.pattern:
        icon = Icons.analytics;
        color = isDark ? AppTheme.darkOrange : AppTheme.darkBlue;
        break;
      case InsightType.recommendation:
        icon = Icons.lightbulb_outline;
        color = Colors.orange;
        break;
      case InsightType.warning:
        icon = Icons.warning;
        color = Colors.red;
        break;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 20),
                const SizedBox(width: 8),
                Text(
                  insight.type.name.toUpperCase(),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: color,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Text(
                  '${(insight.confidence * 100).round()}%',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isDark ? AppTheme.darkOrangeTextSecondary : AppTheme.darkBlueTextSecondary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              insight.title,
              style: theme.textTheme.titleMedium,
            ),
            const SizedBox(height: 4),
            Text(
              insight.description,
              style: theme.textTheme.bodyMedium,
            ),
            if (insight.actionable && insight.actionText != null) ...[
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Action: ${insight.actionText}'),
                      backgroundColor: color,
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: color,
                  foregroundColor: Colors.white,
                ),
                child: Text(insight.actionText!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
