import 'package:flutter/material.dart';
import 'lib/screens/daily_checkin_screen.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Test navigation to daily check-in screen
            print('Testing daily check-in navigation...');
          },
          child: Text('Test Daily Check-In'),
        ),
      ),
    ),
  ));
}
