import 'package:flutter/material.dart';
import 'lib/screens/home_screen.dart';

void main() {
  runApp(TestApp());
}

class TestApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Navigation Test',
      home: TestNavigationScreen(),
    );
  }
}

class TestNavigationScreen extends StatefulWidget {
  @override
  _TestNavigationScreenState createState() => _TestNavigationScreenState();
}

class _TestNavigationScreenState extends State<TestNavigationScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Navigation Test')),
      body: Column(
        children: [
          Text('Current Index: $_currentIndex'),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _currentIndex = 1;
              });
            },
            child: Text('Test Navigation to Index 1'),
          ),
          Expanded(
            child: HomeScreen(
              onNavigateToTab: (index) {
                print('Test: Received navigation request for index: $index');
                setState(() {
                  _currentIndex = index;
                });
                print('Test: Current index updated to: $_currentIndex');
              },
            ),
          ),
        ],
      ),
    );
  }
}
