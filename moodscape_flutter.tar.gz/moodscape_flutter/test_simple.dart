import 'package:flutter/material.dart';

void main() {
  runApp(SimpleTestApp());
}

class SimpleTestApp extends StatefulWidget {
  @override
  _SimpleTestAppState createState() => _SimpleTestAppState();
}

class _SimpleTestAppState extends State<SimpleTestApp> {
  int _currentIndex = 0;

  void _navigateToTab(int index) {
    print('Navigating to tab: $index');
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple Navigation Test',
      home: Scaffold(
        appBar: AppBar(title: Text('Navigation Test')),
        body: Column(
          children: [
            Text('Current Tab: $_currentIndex'),
            ElevatedButton(
              onPressed: () => _navigateToTab(1),
              child: Text('Go to Tab 1'),
            ),
            ElevatedButton(
              onPressed: () => _navigateToTab(2),
              child: Text('Go to Tab 2'),
            ),
            Expanded(
              child: IndexedStack(
                index: _currentIndex,
                children: [
                  Container(
                    color: Colors.red,
                    child: Center(child: Text('Tab 0 - Red')),
                  ),
                  Container(
                    color: Colors.green,
                    child: Center(child: Text('Tab 1 - Green')),
                  ),
                  Container(
                    color: Colors.blue,
                    child: Center(child: Text('Tab 2 - Blue')),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
